/*===================================================================================

  copyright: (C) Copyright 2003-2004 Filemaker, Inc. All Rights Reserved
  
  =================================================================================*/

window.errs = {
	http:		false,
	e_100_0:	"La base de datos no está abierta:\r\rNo se puede procesar su petición porque la base de datos \"^1\" no está abierta.",
	e_101_0:	"No se encuentra el registro:\r\rNo se ha encontrado el registro especificado.",
	e_102_0:	"No se encuentra el campo:\r\rNo se ha encontrado el campo especificado.",
	e_105_0:	"No se encuentra la presentación:\r\rNo se puede procesar su petición porque no se pudo acceder \"^1\" a la presentación.",
	e_200_0:	"Restricción de acceso:\r\rNo tiene privilegios de acceso para realizar la acción: ^1",
	e_211_0:	"La contraseña ha caducado",
	e_301_0:	"Registro en uso:\r\rNo se ha podido ^1 el registro porque otro usuario lo está utilizando actualmente.",
	e_301_1:	"eliminar",
	e_301_2:	"editar",
	e_400_0:	"No hay ningún criterio válido en esta petición. Escriba una petición válida antes de hacer clic en Ejecutar búsqueda.",
	e_401_0:	"No se ha encontrado ningún registro:\r\rNo se ha encontrado ningún registro en la base de datos \"^1\" para la búsqueda que ha especificado. Modifique los criterios de búsqueda y vuelva a intentarlo.",
	entry_0:	"Error en la introducción de datos:\r\rNo se pudieron guardar los cambios en el nuevo registro por las siguientes razones:\r\r",
	entry_1:	"Error en la introducción de datos:\r\rNo se pudieron guardar los cambios en el registro actual por las siguientes razones:\r\r",
	e_500_0:	"Valor de fecha no válido en el campo \"^1.\"",
	e_501_0:	"Valor de hora no válido en el campo \"^1.\"",
	e_502_0:	"Valor numérico no válido en el campo \"^1.\"",
	e_503_0:	"Valor fuera de rango en el campo \"^1.\"",
	e_504_0:	"El campo requiere un valor único \"^1.\"",
	e_505_0:	"El campo requiere un valor existente \"^1.\"",
	e_506_0:	"Elija el contenido del campo en la lista de valores para el campo \"^1.\"",
	e_507_0:	"El cálculo de validación no acepta el valor en el campo \"^1.\"",
	e_509_0:	"Contenido requerido del campo:\r\rHay que introducir valores en el campo siguiente: \"^1.\"",
	e_510_0:	"Falta el valor de unión para crear el registro relacionado.",
	e_802_0:	"Se ha superado el número máximo de usuarios que pueden conectarse a este servidor.",
	e_803_0:	"Otro usuario ya ha abierto la base de datos \"^1\".",
	e_default:	"Error desconocido número ^1."
};