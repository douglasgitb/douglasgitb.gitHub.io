/*===================================================================================

  copyright: (C) Copyright 2003-2004 Filemaker, Inc. All Rights Reserved
  
  =================================================================================*/

window.errs = {
	http:		false,
	e_100_0:	"Datenbank nicht geöffnet:\r\rIhre Anfrage konnte nicht verarbeitet werden, weil die Datenbank \"^1\" nicht geöffnet ist.",
	e_101_0:	"Datensatz nicht gefunden:\r\rDer angegebene Datensatz wurde nicht gefunden.",
	e_102_0:	"Feld nicht gefunden:\r\rDas angegebene Feld wurde nicht gefunden.",
	e_105_0:	"Layout nicht gefunden:\r\rIhre Anfrage konnte nicht verarbeitet werden, weil nicht auf das Layout \"^1\" zugegriffen werden konnte.",
	e_200_0:	"Zugriffsbeschränkung:\r\rSie verfügen nicht über die erforderlichen Zugriffsrechte, um diese Aktion durchzuführen: ^1",
	e_211_0:	"Passwort abgelaufen.",
	e_301_0:	"Datensatz in Gebrauch:\r\rIhr Versuch, den Datensatz zu ^1, ist fehlgeschlagen, weil ein anderer Benutzer den Datensatz gerade verwendet.",
	e_301_1:	"löschen",
	e_301_2:	"bearbeiten",
	e_400_0:	"In dieser Abfrage befinden sich keine gültigen Suchkriterien. Geben Sie eine gültige Abfrage ein, bevor Sie auf \"Suchen\" klicken.",
	e_401_0:	"Keine Datensätze gefunden:\r\rIn der Datenbank \"^1\" wurden keine Datensätze für die von Ihnen angegebene Suche gefunden. Ändern Sie Ihre Suchkriterien und versuchen Sie es erneut.",
	entry_0:	"Dateneingabefehler:\r\rIhr Versuch, Änderungen an dem neuen Datensatz zu speichern, ist fehlgeschlagen. Grund:\r\r",
	entry_1:	"Dateneingabefehler:\r\rIhr Versuch, Änderungen an dem aktuellen Datensatz zu speichern, ist fehlgeschlagen. Grund:\r\r",
	e_500_0:	"Ungültiger Datumswert in Feld \"^1\".",
	e_501_0:	"Ungültiger Zeitwert in Feld \"^1\".",
	e_502_0:	"Ungültiger Zahlenwert in Feld \"^1\".",
	e_503_0:	"Wert nicht im Bereich in Feld \"^1\".",
	e_504_0:	"In Feld \"^1\" ist ein eindeutiger Wert erforderlich.",
	e_505_0:	"In Feld \"^1\" ist ein existierender Wert erforderlich.",
	e_506_0:	"Wählen Sie für \"^1\" den Feldinhalt aus der Werteliste.",
	e_507_0:	"Wert in Feld \"^1\" wird durch die Überprüfungsberechnung nicht akzeptiert",
	e_509_0:	"Erforderlicher Feldinhalt:\r\rFür folgendes Feld müssen Werte angegeben werden: \"^1.\"",
	e_510_0:	"Join-Wert für die Erstellung des Bezugsdatensatzes fehlt.",
	e_802_0:	"Die maximale Anzahl zulässiger Benutzer für eine Verbindung zu diesem Server wurde überschritten.",
	e_803_0:	"Die Datenbank \"^1\" wurde bereits durch einen anderen Benutzer geöffnet.",
	e_default:	"Unbekannter Fehler Nr. ^1."
};