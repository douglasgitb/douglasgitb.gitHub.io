/*===================================================================================

  copyright: (C) Copyright 2003-2004 Filemaker, Inc. All Rights Reserved
  
  =================================================================================*/

window.errs = {
	http:		true,
	e_200_0:	"Correcto\r\rNo hay ningún error.",
	e_204_0:	"No se encuentran registros\r\rNinguno de los registros coincide con los criterios de búsqueda.",
	e_400_0:	"Petición incorrecta\r\rEl servidor no pudo procesar la petición debido a un error de sintaxis.",
	e_400_1:	"Petición incorrecta\r\rEl servidor no pudo procesar la petición porque una URL no es correcta.",
	e_400_2:	"Petición incorrecta\r\rEl servidor no pudo procesar la petición porque falta un parámetro: \"^1\".",
	e_400_3:	"Petición incorrecta\r\rEl servidor no pudo procesar la petición porque hay un campo vacío: \"^1\".",
	e_400_4:	"Petición incorrecta\r\rEl servidor no pudo procesar la petición porque hay algún parámetro no válido: \"^1\".",
	e_400_5:	"Petición incorrecta\r\rEl servidor no pudo procesar la petición porque uno de los parámetros está en desuso: \"^1\".",
	e_400_6:	"Petición incorrecta\r\rEl servidor no pudo procesar la petición porque falta un comando: \"^1\".",
	e_400_7:	"Petición incorrecta\r\rEl servidor no pudo procesar la petición porque hay comandos en conflicto.",
	e_400_8:	"Petición incorrecta\r\rEl servidor no pudo procesar la petición porque falta una especificación de la base de datos.",
	e_400_9:	"Petición incorrecta\r\rEl servidor no pudo procesar la petición porque falta una especificación de la presentación.",
	e_400_10:	"Petición incorrecta\r\rEl servidor no pudo procesar la petición porque no se admite la gramática: \"^1\".",
	e_400_11:	"Petición incorrecta\r\rEl servidor no pudo procesar la petición porque se ha formado una consulta incorrectamente (#^1).",
	e_400_12:	"Petición incorrecta\r\rEl servidor no pudo procesar la petición porque se ha terminado el tiempo de espera de la sesión.\r\rVuelva a seleccionar la base de datos para iniciar una nueva sesión.",
	e_403_0:	"Prohibido\r\rNo tiene autorización para acceder a este servidor.",
	e_403_1:	"Se ha superado el límite de usuarios\r\rEstá conectados el número máximo de usuarios con licencia. Vuelva a intentarlo más adelante.",
	e_404_0:	"No se encuentra\r\rLa URL solicitada \"^1\" no se encuentra en este servidor.",
	e_417_0:	"Fallo en la previsión\r\rEl servidor no pudo ejecutar la actualización solicitada (#^1).",
	e_500_0:	"Error interno del servidor\r\rSe ha producido un error interno del servidor.",
	e_500_1:	"Error interno del servidor\r\rSe ha producido un error en FileMaker Server (#^1).",
	e_500_2:	"Error interno del servidor\r\rNo se encuentra FileMaker Server (#^1).",
	e_501_0:	"No implementada\r\rEl servidor no admite las funciones necesarias para realizar esta petición.",
	e_505_0:	"Versión de HTTP no admitida\r\rEl servidor no admite la versión del protocolo HTTP que se utilizó en el mensaje de solicitud.",
	e_default:	"Error desconocido número ^1."
};
