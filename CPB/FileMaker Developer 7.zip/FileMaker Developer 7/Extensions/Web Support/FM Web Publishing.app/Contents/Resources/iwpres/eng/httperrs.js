/*===================================================================================

  copyright: (C) Copyright 2003-2004 Filemaker, Inc. All Rights Reserved
  
  =================================================================================*/

window.errs = {
	http:		true,
	e_200_0:	"OK\r\rNo Error.",
	e_204_0:	"No Records Found\r\rNo records matched the search criteria.",
	e_400_0:	"Bad Request\r\rThe server could not process your request due to a syntax error.",
	e_400_1:	"Bad Request\r\rThe server could not process your request due to a malformed url.",
	e_400_2:	"Bad Request\r\rThe server could not process your request due to a missing parameter: \"^1\".",
	e_400_3:	"Bad Request\r\rThe server could not process your request due to an empty field: \"^1\".",
	e_400_4:	"Bad Request\r\rThe server could not process your request due to an illegal parameter: \"^1\".",
	e_400_5:	"Bad Request\r\rThe server could not process your request due to a deprecated parameter: \"^1\".",
	e_400_6:	"Bad Request\r\rThe server could not process your request due to a missing command: \"^1\".",
	e_400_7:	"Bad Request\r\rThe server could not process your request due to conflicting commands.",
	e_400_8:	"Bad Request\r\rThe server could not process your request due to missing a database specification.",
	e_400_9:	"Bad Request\r\rThe server could not process your request due to missing a layout specification.",
	e_400_10:	"Bad Request\r\rThe server could not process your request due to an unsupported grammar: \"^1\".",
	e_400_11:	"Bad Request\r\rThe server could not process your request due to an incorrectly formed query (#^1).",
	e_400_12:	"Bad Request\r\rThe server could not process your request because your session has timed out.\r\rPlease reselect the database to begin a new session.",
	e_403_0:	"Forbidden\r\rYou do not have authorization to access this server.",
	e_403_1:	"User Limit Exceeded\r\rThe maximum number of licensed users are connected. Try again later.",
	e_404_0:	"Not Found\r\rThe requested URL \"^1\" was not found on this server.",
	e_417_0:	"Expectation Failed\r\rThe server could not perform the requested update (#^1).",
	e_500_0:	"Internal Server Error\r\rAn internal server error has occurred.",
	e_500_1:	"Internal Server Error\r\rA FileMaker Server error has occurred (#^1).",
	e_500_2:	"Internal Server Error\r\rNo FileMaker Server was found (#^1).",
	e_501_0:	"Not Implemented\r\rThe server does not support the functionality required to fulfill this request.",
	e_505_0:	"HTTP Version Not Supported\r\rThe server does not support the HTTP protocol version that was used in the request message.",
	e_default:	"Unknown error number ^1."
};
