/*===================================================================================

  copyright: (C) Copyright 2003-2004 Filemaker, Inc. All Rights Reserved
  
  =================================================================================*/

window.errs = {
	http:		true,
	e_200_0:	"OK\r\rInget fel.",
	e_204_0:	"Inga poster hittades\r\rInga poster stämde överens med sökvillkoren.",
	e_400_0:	"Ogiltig begäran\r\rServern kunde inte bearbeta din begäran på grund av ett syntaxfel.",
	e_400_1:	"Ogiltig begäran\r\rServern kunde inte bearbeta din begäran på grund av en felaktig URL-adress.",
	e_400_2:	"Ogiltig begäran\r\rServern kunde inte bearbeta din begäran, eftersom en parameter saknas: \"^1\".",
	e_400_3:	"Ogiltig begäran\r\rServern kunde inte bearbeta din begäran, eftersom ett fält är tomt: \"^1\".",
	e_400_4:	"Ogiltig begäran\r\rServern kunde inte bearbeta din begäran på grund av en ogiltig parameter: \"^1\".",
	e_400_5:	"Ogiltig begäran\r\rServern kunde inte bearbeta din begäran på grund av en felaktig parameter: \"^1\".",
	e_400_6:	"Ogiltig begäran\r\rServern kunde inte bearbeta din begäran, eftersom ett kommando saknas: \"^1\".",
	e_400_7:	"Ogiltig begäran\r\rServern kunde inte bearbeta din begäran på grund av motstridiga kommandon.",
	e_400_8:	"Ogiltig begäran\r\rServern kunde inte bearbeta din begäran, eftersom en databasspecifikation saknas.",
	e_400_9:	"Ogiltig begäran\r\rServern kunde inte bearbeta din begäran, eftersom en layoutspecifikation saknas.",
	e_400_10:	"Ogiltig begäran\r\rServern kunde inte bearbeta din begäran, eftersom grammatiken saknar stöd: \"^1\".",
	e_400_11:	"Ogiltig begäran\r\rServern kunde inte bearbeta din begäran på grund av en felaktigt utformad fråga (#^1).",
	e_400_12:	"Ogiltig begäran\r\rServern kunde inte bearbeta din begäran, eftersom tidsgränsen för sessionen har uppnåtts.\r\rStarta en ny session genom att välja databasen igen.",
	e_403_0:	"Förbjudet\r\rDu har inte behörighet för att använda den här servern.",
	e_403_1:	"Användarbegränsningen har uppnåtts\r\rDet högsta antalet licensierade användare är anslutna. Försök igen senare.",
	e_404_0:	"Hittades inte\r\rDen begärda URL-adressen \"^1\" påträffades inte på den här servern.",
	e_417_0:	"Åtgärden misslyckades\r\rServern kunde inte utföra den begärda uppdateringen (#^1).",
	e_500_0:	"Internt serverfel\r\rEtt internt serverfel har inträffat.",
	e_500_1:	"Internt serverfel\r\rEtt FileMaker Server-fel har inträffat (#^1).",
	e_500_2:	"Internt serverfel\r\rIngen FileMaker Server påträffades (#^1).",
	e_501_0:	"Ej implementerat\r\rServern stöder inte den funktion som krävs för att fullgöra denna begäran.",
	e_505_0:	"HTTP-versionen stöds inte\r\rServern stöder inte den version av HTTP-protokollet som användes i denna begäran.",
	e_default:	"Okänt fel nummer ^1."
};
