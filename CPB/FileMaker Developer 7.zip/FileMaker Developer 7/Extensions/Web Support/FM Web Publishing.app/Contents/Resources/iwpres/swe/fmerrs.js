/*===================================================================================

  copyright: (C) Copyright 2003-2004 Filemaker, Inc. All Rights Reserved
  
  =================================================================================*/
  
window.errs = {
	http:		false,
	e_100_0:	"Databasen är inte öppen:\r\rDet gick inte att bearbeta din begäran, eftersom databasen \"^1\" inte är öppen.",
	e_101_0:	"Posten hittades inte:\r\rDen angivna posten hittades inte.",
	e_102_0:	"Fältet hittades inte:\r\rDet angivna fältet hittades inte.",
	e_105_0:	"Layouten hittades inte:\r\rDet gick inte att bearbeta din begäran, eftersom layouten \"^1\" inte kunde öppnas.",
	e_200_0:	"Behörighetsbegränsning:\r\rDu har inte behörighet för att utföra följande åtgärd: ^1",
	e_211_0:	"Lösenordet har upphört att gälla",
	e_301_0:	"Posten används:\r\rDitt försök att ^1 posten misslyckades, eftersom en annan användare använder posten för närvarande.",
	e_301_1:	"radera",
	e_301_2:	"ändra",
	e_400_0:	"Giltiga sökvillkor saknas. Ange ett giltigt villkor innan du klickar på Utför sökning.",
	e_401_0:	"Inga poster hittades:\r\rInga poster hittades i databasen \"^1\" för den sökning som du angav. Ändra sökvillkoren och försök igen.",
	entry_0:	"Datainmatningsfel:\r\rDitt försök att spara ändringar i den nya posten misslyckades av följande anledning:\r\r",
	entry_1:	"Datainmatningsfel:\r\rDitt försök att spara ändringar i den aktuella posten misslyckades av följande anledning:\r\r",
	e_500_0:	"Ogiltigt datumvärde i fältet \"^1.\"",
	e_501_0:	"Ogiltigt tidsvärde i fältet \"^1.\"",
	e_502_0:	"Ogiltigt numeriskt värde i fältet \"^1.\"",
	e_503_0:	"Värde utanför det tillåtna intervallet i fältet \"^1.\"",
	e_504_0:	"Ett unikt värde krävs i fältet \"^1.\"",
	e_505_0:	"Ett befintligt värde krävs i fältet \"^1.\"",
	e_506_0:	"Välj fältinnehåll i värdelistan för fältet \"^1.\"",
	e_507_0:	"Värdet godkändes inte av kontrollberäkningen i fältet \"^1.\"",
	e_509_0:	"Obligatoriskt fältinnehåll:\r\rDu måste ange värden för följande fält: \"^1.\"",
	e_510_0:	"Kopplingsvärde för att skapa en relaterad post saknas.",
	e_802_0:	"Det högsta tillåtna antalet användare som får ansluta till den här servern har överskridits.",
	e_803_0:	"Databasen \"^1\" har redan öppnats av en annan användare.",
	e_default:	"Okänt fel nummer ^1."
};