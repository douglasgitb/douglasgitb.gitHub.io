/*===================================================================================

  copyright: (C) Copyright 2003-2004 Filemaker, Inc. All Rights Reserved
  
  =================================================================================*/

window.errs = {
	http:		false,
	e_100_0:	"Base de données non ouverte :\r\rImpossible de traiter votre requête car la base de données \"^1\" n'est pas ouverte.",
	e_101_0:	"Enregistrement introuvable :\r\rL'enregistrement spécifié n'a pas été trouvé.",
	e_102_0:	"Rubrique introuvable :\r\rLa rubrique spécifiée n'a pas été trouvée.",
	e_105_0:	"Modèle introuvable :\r\rImpossible de traiter votre requête car le modèle \"^1\" est inaccessible.",
	e_200_0:	"Restriction d'accès :\r\rVous ne bénéficiez pas des autorisations d'accès nécessaires pour effectuer cette opération : ^1",
	e_211_0:	"Le mot de passe a expiré.",
	e_301_0:	"Enregistrement en cours d'utilisation :\r\rVotre tentative de ^1 l'enregistrement a échoué car un autre utilisateur travaille actuellement sur cet enregistrement.",
	e_301_1:	"supprimer",
	e_301_2:	"modifier",
	e_400_0:	"Aucun critère valable n’a été saisi pour cette requête. Entrez les données à rechercher avant de cliquer sur Exécuter recherche.",
	e_401_0:	"Aucun enregistrement trouvé :\r\rAucun enregistrement n'a été trouvé dans la base de données \"^1\" pour la recherche spécifiée. Modifiez vos critères de recherche et faites un nouvel essai.",
	entry_0:	"Erreur de saisie de données :\r\rVotre tentative pour sauvegarder des modifications dans le nouvel enregistrement a échoué pour la raison suivante :\r\r",
	entry_1:	"Erreur de saisie de données :\r\rVotre tentative pour sauvegarder des modifications dans l'enregistrement en cours a échoué pour la raison suivante :\r\r",
	e_500_0:	"Valeur de la date incorrecte dans la rubrique \"^1.\"",
	e_501_0:	"Valeur de l'heure incorrecte dans la rubrique \"^1.\"",
	e_502_0:	"Valeur numérique incorrecte dans la rubrique \"^1.\"",
	e_503_0:	"Valeur hors intervalle dans la rubrique \"^1.\"",
	e_504_0:	"Une valeur unique est requise dans la rubrique \"^1.\"",
	e_505_0:	"Une valeur existante est requise dans la rubrique \"^1.\"",
	e_506_0:	"Choisissez une valeur dans la liste pour la rubrique \"^1.\"",
	e_507_0:	"Valeur non acceptée par le calcul de validation dans la rubrique \"^1.\"",
	e_509_0:	"Contenu de rubrique requis :\r\rDes valeurs doivent être saisies pour le champ suivant : \"^1.\"",
	e_510_0:	"Valeur de fusion manquante pour créer un enregistrement lié.",
	e_802_0:	"Le nombre maximum de connexions d'utilisateurs à ce serveur a été dépassé.",
	e_803_0:	"La base de données \"^1\" est déjà ouverte par un autre utilisateur.",
	e_default:	"Numéro d'erreur inconnu ^1."
};