/*===================================================================================

  copyright: (C) Copyright 2003-2004 Filemaker, Inc. All Rights Reserved
  
  =================================================================================*/

window.errs = {
	http:		false,
	e_100_0:	"Database niet open:\r\rKan uw verzoek niet verwerken omdat de database \"^1\" niet is geopend.",
	e_101_0:	"Record niet gevonden:\r\rDe opgegeven record is niet gevonden.",
	e_102_0:	"Veld niet gevonden:\r\rHet opgegeven veld is niet gevonden.",
	e_105_0:	"Lay-out niet gevonden:\r\rKan uw verzoek niet verwerken omdat de lay-out \"^1\" niet kan worden geopend.",
	e_200_0:	"Toegangsbeperking:\r\rUw toegangsprivileges zijn ontoereikend om deze actie uit te voeren: ^1",
	e_211_0:	"Wachtwoord is verlopen",
	e_301_0:	"Record wordt al gebruikt:\r\rUw poging om het record te ^1 is mislukt omdat het record momenteel door een andere gebruiker in gebruik is.",
	e_301_1:	"verwijderen",
	e_301_2:	"bewerken",
	e_400_0:	"Dit verzoek bevat geen geldige criteria. Type een geldig verzoek voordat u op Zoeken uitvoeren klikt.",
	e_401_0:	"Geen records gevonden:\r\rEr zijn geen records gevonden in de database \"^1\" voor de zoekopdracht die u hebt opgegeven. Wijzig uw zoekcriteria en probeer het opnieuw.",
	entry_0:	"Fout in gegevensinvoer:\r\rUw poging om wijzigingen in de nieuwe record op te slaan, is mislukt omwille van de volgende reden(en):\r\r",
	entry_1:	"Fout in gegevensinvoer:\r\rUw poging om wijzigingen in de huidige record op te slaan, is mislukt omwille van de volgende reden(en):\r\r",
	e_500_0:	"Ongeldige datumwaarde in het veld \"^1\".",
	e_501_0:	"Ongeldige tijdwaarde in het veld \"^1\".",
	e_502_0:	"Ongeldige numerieke waarde in het veld \"^1\".",
	e_503_0:	"Waarde buiten bereik in het veld \"^1\".",
	e_504_0:	"In het veld \"^1\" is een unieke waarde vereist.",
	e_505_0:	"In het veld \"^1\" is een bestaande waarde vereist.",
	e_506_0:	"Kies voor het veld \"^1\" de veldinhoud uit een invoerlijst.",
	e_507_0:	"Waarde niet geaccepteerd door validatieberekening in het veld \"^1.\"",
	e_509_0:	"Veldinhoud vereist:\r\rEr moeten waarden worden ingevoerd voor het volgende veld: \"^1\".",
	e_510_0:	"Samenvoegwaarde voor het maken van gerelateerde record ontbreekt.",
	e_802_0:	"Het toegestane maximumaantal gebruikers dat met deze server een verbinding mag maken, is overschreden.",
	e_803_0:	"De database \"^1\" is al door een andere gebruiker geopend.",
	e_default:	"Onbekende fout. Nummer ^1."
};