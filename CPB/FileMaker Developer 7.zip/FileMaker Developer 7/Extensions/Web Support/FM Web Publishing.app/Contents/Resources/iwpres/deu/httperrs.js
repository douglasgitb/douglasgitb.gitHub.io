/*===================================================================================

  copyright: (C) Copyright 2003-2004 Filemaker, Inc. All Rights Reserved
  
  =================================================================================*/

window.errs = {
	http:		true,
	e_200_0:	"OK\r\rKein Fehler.",
	e_204_0:	"Keine Datensätze gefunden.\r\rKeine den Suchkriterien entsprechenden Datensätze.",
	e_400_0:	"Ungültige Abfrage\r\rDer Server konnte Ihre Abfrage aufgrund eines Syntaxfehlers nicht verarbeiten.",
	e_400_1:	"Ungültige Abfrage\r\rDer Server konnte Ihre Abfrage aufgrund einer ungültigen URL nicht verarbeiten.",
	e_400_2:	"Ungültige Abfrage\r\rDer Server konnte Ihre Abfrage aufgrund eines fehlenden Parameters nicht verarbeiten: \"^1\".",
	e_400_3:	"Ungültige Abfrage\r\rDer Server konnte Ihre Abfrage aufgrund eines leeren Felds nicht verarbeiten: \"^1\".",
	e_400_4:	"Ungültige Abfrage\r\rDer Server konnte Ihre Abfrage aufgrund eines falschen Parameters nicht verarbeiten: \"^1\".",
	e_400_5:	"Ungültige Abfrage\r\rDer Server konnte Ihre Abfrage aufgrund eines abgelehnten Parameters nicht verarbeiten: \"^1\".",
	e_400_6:	"Ungültige Abfrage\r\rDer Server konnte Ihre Abfrage aufgrund eines fehlenden Befehls nicht verarbeiten: \"^1\".",
	e_400_7:	"Ungültige Abfrage\r\rDer Server konnte Ihre Abfrage aufgrund widersprüchlicher Befehle nicht verarbeiten.",
	e_400_8:	"Ungültige Abfrage\r\rDer Server konnte Ihre Abfrage aufgrund einer fehlenden Datenbankspezifikation nicht verarbeiten.",
	e_400_9:	"Ungültige Abfrage\r\rDer Server konnte Ihre Abfrage aufgrund einer fehlenden Layoutspezifikation nicht verarbeiten.",
	e_400_10:	"Ungültige Abfrage\r\rDer Server konnte Ihre Abfrage aufgrund einer nicht unterstützten Grammatik nicht verarbeiten: \"^1\".",
	e_400_11:	"Ungültige Abfrage\r\rDer Server konnte Ihre Abfrage aufgrund einer falsch gebildeten Suchabfrage (Nr. ^1) nicht verarbeiten.",
	e_400_12:	"Ungültige Abfrage\r\rDer Server konnte Ihre Abfrage nicht verarbeiten, weil eine Zeitüberschreitung Ihrer Sitzung aufgetreten ist.\r\rWählen Sie die Datenbank erneut aus, um eine neue Sitzung zu starten.",
	e_403_0:	"Kein Zugriff\r\rSie haben keine Berechtigung, um auf diesen Server zuzugreifen.",
	e_403_1:	"Benutzerlimit überschritten\r\rDie maximale Anzahl an lizenzierten Benutzern ist bereits verbunden. Versuchen Sie es später erneut.",
	e_404_0:	"Nicht gefunden\r\rDie angeforderte URL \"^1\" wurde nicht auf diesem Server gefunden.",
	e_417_0:	"Annahme fehlerhaft\r\rDer Server konnte die angeforderte Aktualisierung (Nr. ^1) nicht durchführen.",
	e_500_0:	"Interner Server-Fehler\r\rEin interner Server-Fehler ist aufgetreten.",
	e_500_1:	"Interner Server-Fehler\r\rEin FileMaker Server-Fehler ist aufgetreten (Nr. ^1).",
	e_500_2:	"Interner Server-Fehler\r\rKein FileMaker Server gefunden (Nr. ^1).",
	e_501_0:	"Nicht implementiert\r\rDer Server unterstützt die für die Erfüllung dieser Anforderung erforderliche Funktion nicht.",
	e_505_0:	"HTTP-Version nicht unterstützt\r\rDer Server unterstützt die http-Protokollversion, die in der Anfragenachricht verwendet wurde, nicht.",
	e_default:	"Unbekannter Fehler Nr. ^1."
};