/*===================================================================================

  copyright: (C) Copyright 2003-2004 Filemaker, Inc. All Rights Reserved
  
  =================================================================================*/

window.errs = {
	http:		false,
	e_100_0:	"Database Not Open:\r\rUnable to process your request because the database \"^1\" is not open.",
	e_101_0:	"Record Not Found:\r\rThe specified record was not found.",
	e_102_0:	"Field Not Found:\r\rThe specified field was not found.",
	e_105_0:	"Layout Not Found:\r\rUnable to process your request because the layout \"^1\" could not be accessed.",
	e_200_0:	"Access Restriction:\r\rYou do not have access privileges to perform the action: ^1",
	e_211_0:	"Password has expired.",
	e_301_0:	"Record in Use:\r\rYour attempt to ^1 the record failed because another user is currently using the record.",
	e_301_1:	"delete",
	e_301_2:	"edit",
	e_400_0:	"There are no valid criteria in this request. Type a valid request before clicking Perform Find.",
	e_401_0:	"No Records Found:\r\rNo records were found in the database \"^1\" for the search you specified. Modify your search criteria and try again.",
	entry_0:	"Data Entry Error:\r\rYour attempt to save changes to the new record failed because of the following:\r\r",
	entry_1:	"Data Entry Error:\r\rYour attempt to save changes to the current record failed because of the following:\r\r",
	e_500_0:	"Invalid date value in field \"^1.\"",
	e_501_0:	"Invalid time value in field \"^1.\"",
	e_502_0:	"Invalid numeric value in field \"^1.\"",
	e_503_0:	"Value out of range in field \"^1.\"",
	e_504_0:	"A unique value is required in field \"^1.\"",
	e_505_0:	"An existing value is required in field \"^1.\"",
	e_506_0:	"Choose field contents from value list for field \"^1.\"",
	e_507_0:	"Value not accepted by validation calculation in field \"^1.\"",
	e_509_0:	"Required Field Contents:\r\rValues must be entered for the following field: \"^1.\"",
	e_510_0:	"Missing join value for creating related record.",
	e_802_0:	"The maximum number of users allowed to connect to this server has been exceeded.",
	e_803_0:	"The database \"^1\" has already been opened by another user.",
	e_default:	"Unknown error number ^1."
};
