/*===================================================================================

  copyright: (C) Copyright 2003-2004 Filemaker, Inc. All Rights Reserved
  
  =================================================================================*/

window.errs = {
	http:		true,
	e_200_0:	"OK\r\rNessun errore.",
	e_204_0:	"Nessun record trovato\r\rNessun record corrisponde ai criteri di ricerca.",
	e_400_0:	"Richiesta non corretta\r\rIl server non ha potuto elaborare la richiesta a causa di un errore di sintassi.",
	e_400_1:	"Richiesta non corretta\r\rIl server non ha potuto elaborare la richiesta a causa di un URL errato.",
	e_400_2:	"Richiesta non corretta\r\rIl server non ha potuto elaborare la richiesta a causa di un parametro mancante: \"^1\".",
	e_400_3:	"Richiesta non corretta\r\rIl server non ha potuto elaborare la richiesta a causa di un campo vuoto: \"^1\".",
	e_400_4:	"Richiesta non corretta\r\rIl server non ha potuto elaborare la richiesta a causa di un parametro non corretto: \"^1\".",
	e_400_5:	"Richiesta non corretta\r\rIl server non ha potuto elaborare la richiesta a causa di un parametro obsoleto: \"^1\".",
	e_400_6:	"Richiesta non corretta\r\rIl server non ha potuto elaborare la richiesta a causa di un comando mancante: \"^1\".",
	e_400_7:	"Richiesta non corretta\r\rIl server non ha potuto elaborare la richiesta a causa di un conflitto tra comandi.",
	e_400_8:	"Richiesta non corretta\r\rIl server non ha potuto elaborare la richiesta a causa di specifiche database mancanti.",
	e_400_9:	"Richiesta non corretta\r\rIl server non ha potuto elaborare la richiesta a causa di specifiche formato mancanti.",
	e_400_10:	"Richiesta non corretta\r\rIl server non ha potuto elaborare la richiesta a causa di una grammatica non supportata: \"^1\".",
	e_400_11:	"Richiesta non corretta\r\rIl server non ha potuto elaborare la richiesta a causa di una query creata in modo non corretto (#^1).",
	e_400_12:	"Richiesta non corretta\r\rIl server non ha potuto elaborare la richiesta perché la sessione è scaduta.\r\rSelezionare nuovamente il database per avviare una nuova sessione.",
	e_403_0:	"Proibito\r\rL'utente non dispone dell'autorizzazione per accedere a questo server.",
	e_403_1:	"Limite utenti superato\r\rIl numero massimo di utenti con licenza è connesso. Riprovare più tardi.",
	e_404_0:	"Non trovato\r\rL'URL richiesto \"^1\" non è stato trovato su questo server.",
	e_417_0:	"Previsione non riuscita\r\rIl server non è riuscito ad eseguire l'aggiornamento richiesto (#^1).",
	e_500_0:	"Errore interno del server\r\rSi è verificato un errore interno del server.",
	e_500_1:	"Errore interno del server\r\rSi è verificato un errore di FileMaker Server (#^1).",
	e_500_2:	"Errore interno del server\r\rNon è stato trovato nessun FileMaker Server (#^1).",
	e_501_0:	"Non implementato\r\rIl server non supporta la funzionalità necessaria per soddisfare questa richiesta.",
	e_505_0:	"Versione HTTP non supportata\r\rIl server non supporta la versione del protocollo HTTP usata nel messaggio della richiesta.",
	e_default:	"Numero errore ^1 sconosciuto."
};
