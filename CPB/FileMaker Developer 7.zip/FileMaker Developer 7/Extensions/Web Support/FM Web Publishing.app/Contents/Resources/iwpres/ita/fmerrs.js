/*===================================================================================

  copyright: (C) Copyright 2003-2004 Filemaker, Inc. All Rights Reserved
  
  =================================================================================*/

window.errs = {
	http:		false,
	e_100_0:	"Database non aperto:\r\rNon è possibile elaborare la richiesta perché il database \"^1\" non è aperto.",
	e_101_0:	"Record non trovato:\r\rIl record specificato non è stato trovato.",
	e_102_0:	"Campo non trovato:\r\rIl campo specificato non è stato trovato.",
	e_105_0:	"Formato non trovato:\r\rNon è possibile elaborare la richiesta perché \"^1\" non è stato possibile accedere al formato.",
	e_200_0:	"Limitazione di accesso:\r\rL'utente non dispone dei privilegi di accesso per eseguire l'azione: ^1",
	e_211_0:	"La password è scaduta",
	e_301_0:	"Record in uso:\r\rIl tentativo di ^1 il record è fallito perché un altro utente sta usando il record.",
	e_301_1:	"eliminare",
	e_301_2:	"modificare",
	e_400_0:	"Questa richiesta non contiene criteri validi. Inserire una richiesta valida prima di fare clic su Esegui ricerca.",
	e_401_0:	"Nessun record trovato:\r\rNon è stato trovato nessun record nel database \"^1\" per la ricerca specificata. Modificare i criteri di ricerca e riprovare.",
	entry_0:	"Errore di inserimento dati:\r\rIl tentativo di salvare le modifiche al nuovo record è fallito a causa di:\r\r",
	entry_1:	"Errore di inserimento dati:\r\rIl tentativo di salvare le modifiche al record corrente è fallito a causa di:\r\r",
	e_500_0:	"Valore data non valido nel campo \"^1.\"",
	e_501_0:	"Valore ora non valido nel campo \"^1.\"",
	e_502_0:	"Valore numerico non valido nel campo \"^1.\"",
	e_503_0:	"Valore non compreso nell'intervallo valido nel campo \"^1.\"",
	e_504_0:	"Valore univoco richiesto nel campo \"^1.\"",
	e_505_0:	"Valore esistente richiesto nel campo \"^1.\"",
	e_506_0:	"Scegliere dalla lista valori i contenuti per il campo \"^1.\"",
	e_507_0:	"Valore non accettato dal calcolo di verifica nel campo \"^1.\"",
	e_509_0:	"Contenuto campo richiesto:\r\rInserire valori per il seguente campo: \"^1.\"",
	e_510_0:	"Valore di collegamento mancante per la creazione del record correlato.",
	e_802_0:	"Il numero massimo di utenti autorizzati a connettersi a questo server è stato superato.",
	e_803_0:	"Il database \"^1\" è già stato aperto da un altro utente.",
	e_default:	"Numero errore sconosciuto ^1."
};