/*===================================================================================

  copyright: (C) Copyright 2003-2004 Filemaker, Inc. All Rights Reserved
  
  =================================================================================*/

function IWPObj()
{
	/***** utility methods *****************************************/
	
	this.addOrReplaceTextNode = function( doc, objID, str, replace )
	{
		if( doc != null && objID != null && str != null )
		{
			var obj = doc.getElementById( objID );
			if( obj != null )
			{
				var txt = doc.createTextNode( str );
				if( replace != null )
				{
					if( obj.hasChildNodes() )
					{
						if( obj.childNodes.length > replace )
						{
							var node = obj.childNodes.item( replace );
							obj.replaceChild( txt, node );
						}
						else
							obj.appendChild( txt );
					}
					else
						obj.appendChild( txt );
				}
				else
					obj.appendChild( txt );
			}
		}
	}
	
	this.cgiPath = function()
	{
		bFrame = this.bodyFrame;
		if( bFrame != null && bFrame.iwpinfo != null )
		{
			var path = bFrame.iwpinfo.cgipath;
			if( this.debugurl && bFrame.iwpinfo.debug != null  )
			{
				path = bFrame.iwpinfo.debug;
			}
			return path;
		}
		else
			return null;
	}
	
	this.checkForSafari10 = function()
	{
		var result = false;
		var targ = "AppleWebKit";
		var av = navigator.appVersion;
		var start = av.indexOf(targ);
		if( start > -1 )
		{
			start = start + targ.length + 1;
			var end = av.indexOf(" ", start) - start;
			vers = parseFloat( av.substr( start, end ) );
			if( vers < 103 )
				result = true;
		}
		return result;
	}
	
	this.executebuttonscript = function( index, parentrecid, childrecid )
	{
		if( index != null )
			if ( parentrecid != null && childrecid != null )
				this.submitAndContinue( [{target: "-type", n: "-index", v: index},
					{target: "-omitstate", n: "-recid", v: parentrecid},
					{target: "-relatedrecid", n: "-relatedrecid", v: childrecid},
					{target: "-submitclose", n: "-buttonscript", v: ""}] );
			else
			//	if there is no recid execute the buttonscript without specifying it
				this.submitAndContinue( [{target: "-type", n: "-index", v: index},
					{target: "-submitclose", n: "-buttonscript", v: ""}] );
	}
	
	this.objectEnabled = function( obj )
	{
		if( obj != null && obj.id != null && this.objstate != null )
		{
			var state = this.objstate[obj.id]
			if( state != null )
				return ! state;
		}
		return false;
	}
	
	this.openUrlWindows = function( args )
	{
		if( args != null && args.length )
		{
			for( var i in args )
				window.open( args[i] );
		}
	}
	
	this.setAltAttributes = function( doc, objID, str )
	{
		if( doc != null && objID != null && str != null )
		{
			var obj = doc.getElementById( objID );
			if( obj != null )
			{
				obj.setAttribute( "title", str );
				obj.setAttribute( "alt", str );
			}
		}
	}
	
	this.setAttribute = function( doc, objID, att, val )
	{
		if( doc != null && objID != null && att != null && val != null )
		{
			var obj = doc.getElementById( objID );
			if( obj != null )
				obj.setAttribute( att, val );
		}
	}
	
	this.setImgButtonState = function( doc, objID, img, disabled )
	{
		if( doc != null && objID != null && img != null )
		{
			var url = this.imgPath + img;
			if( disabled == null ) disabled = false;
			if( disabled )
				url += "_x.gif";
			else
				url += "_n.gif";
			var obj = doc.getElementById( objID );
			if( obj != null )
				obj.src = url;
			this.objstate[objID] = disabled;
		}
	}
	
	this.setObjVisibility = function( doc, objID, visible )
	{
		if( doc != null && objID != null && visible != null )
		{
			var obj = doc.getElementById( objID );
			if( obj != null )
			{
				if( visible )
					obj.style.visibility = "visible";
				else
					obj.style.visibility = "hidden";
			}
		}
	}

	this.setTop = function( doc, objID, pos )
	{
		if( doc != null && objID != null && pos != null )
		{
			var obj = doc.getElementById( objID );
			if( obj != null && obj.style != null )
				obj.style.top = parseFloat(pos) + "px";
		}
	}
	
	this.setupRollover = function( doc, objID, name )
	{
		if( doc != null && objID != null && name != null )
		{
			var obj = doc.getElementById( objID );
			if( obj != null )
			{
				var baseUrl = this.imgPath + name;
				var norm = new Image();
				var url = baseUrl + "_n.gif";
				norm.src = url;
				var roll = new Image();
				url = baseUrl + "_o.gif";
				roll.src = url;
				var down = new Image();
				url = baseUrl + "_d.gif";
				down.src = url;
				obj.images = new Array(norm, roll, down);
				this.objstate[objID] = false;
			}
		}
	}
	
	this.setValue = function( doc, objID, val )
	{
		if( doc != null && objID != null && val != null )
		{
			var obj = doc.getElementById( objID );
			if( obj != null )
			{
				try
				{
					obj.value = val;
				}
				catch(e){}
			}
		}
	}

	this.showToolBox = function( show )
	{
		var sFrame = this.statusFrame;
		if( sFrame != null && sFrame.document != null )
		{
			var sDoc = sFrame.document;
			var toolBox = sDoc.getElementById( "toolBox2" );
			var moveBox = sDoc.getElementById( "moveBox" );
			if( toolBox != null && moveBox != null && this.strings != null )
			{
				if( show )
				{
					toolBox.style.visibility = "visible";
					this.positions.visible = true;
					if( this.positions.oldTop == null )
						this.positions.oldTop = moveBox.style.top;
					if( this.positions.newTop == null )
						this.positions.newTop = ( parseFloat(moveBox.style.top) + parseFloat(toolBox.style.height) ) + "px";
					moveBox.style.top = this.positions.newTop;
					var btn = sDoc.getElementById( "downButton" );
					this.swapImage( btn, 0 );
					this.setObjVisibility( sDoc, "downBox", false );
				}
				else
				{
					toolBox.style.visibility = "hidden";
					this.positions.visible = false;
					moveBox.style.top = this.positions.oldTop;
					var btn = sDoc.getElementById( "upButton" );
					this.swapImage( btn, 0 );
					this.setObjVisibility( sDoc, "downBox", true );
				}
			}
		}
	}

	this.submitAndContinue = function( args, target, formname )
	{
		var bFrame = this.bodyFrame;
		var frm = null;
		var url = this.cgiPath();
		if( formname == null )
			formname = "iwpform";
		if( bFrame != null && bFrame.document != null )
			frm = bFrame.document.getElementById( formname );	
		if( frm != null )
		{
			if( args != null )
			{
				for ( var i in args )
				{
					if( args[i].target != null  )
					{
						var obj = frm.elements[ args[i].target ];
						if( obj != null )
						{
							obj.setAttribute("name", args[i].n);
							obj.setAttribute("value", args[i].v);
						}
					}
				}
			}
			if( target != null )
				frm.setAttribute("target", target);
			if( this.debugurl )
				frm.setAttribute("action", url);
			frm.submit();
		}
		else if( args != null && url != null )
		{
			var end = args.length - 1;
			for ( var i in args )
			{
				url += args[i].n + "=" + bFrame.escape(args[i].v);
				if( i < end )
					url += "&";
			}
			if( target != null )
			{
				if( target == "_top" )
					window.location = url;
				else
					window.open( url, target, "location=yes,menubar=yes,resizable=yes,scrollbars=yes,status=yes,toolbar=yes" );
			}
			else if( bFrame != null )
				bFrame.location = url;
		}
	}
	
	this.submitFindRequest = function( args )
	{
		var sFrame = this.statusFrame;
		if( args != null && sFrame != null && sFrame.document != null )
		{
			var omit = sFrame.document.getElementById( "omitCheckbox" );
			if( omit != null )
			{
				var flag = "false";
				if( omit.checked == true )
					flag = "true";
				args[args.length] = {target: "-omitstate", n: "-omitstate", v: flag};
				this.submitAndContinue( args );
			}
		}
	}
	
	this.swapImage = function( obj, index )
	{
		if( obj != null && obj.images != null && index > -1 && index < 4 && this.objectEnabled( obj ) )
		{
			var img = obj.images[index].src;
			if( img != null )
				obj.src = img;
		}
	}
	
	this.toggleStatusArea = function( obj )
	{
		if( obj != null && this.objectEnabled( obj ) )
		{
			var status = this.statusVisible;
			var action = "-";
			if( status )
				action += "hidestatus";
			else
				action += "showstatus";
			this.submitAndContinue( [{target: "-submitclose", n: action, v: ""}], "_top" );
		}
	}
	
	this.toggleToolBox = function()
	{
		var sFrame = this.statusFrame;
		if( sFrame != null && sFrame.document != null )
		{
			var sDoc = sFrame.document;
			var toolBox = sDoc.getElementById( "toolBox2" );
			var show = true;
			if( toolBox != null )
			{
				if( toolBox.style.visibility == "visible" )
					show = false;
				this.showToolBox( show );
			}
		}
	}

	this.unimplemented = function()
	{
		alert("Unimplemented!");
	}
	
	/***** setup methods *****************************************/
	
	this.setupControlFrame = function( win, info )
	{
		this.controlFrame = win;
		var cFrame = this.controlFrame;
		if( this.strings != null && cFrame != null && cFrame.document != null )
		{
			var strs = this.strings;
			var status = this.statusVisible;
			var c = cFrame.document;
			if( status )
			{
				this.setAltAttributes( c, "toggleButton", strs.cont_hlp_collapse );
				this.setupRollover( c, "toggleButton", "collapse" );
			}
			else
			{
				this.setAltAttributes( c, "toggleButton", strs.cont_hlp_expand );
				this.setupRollover( c, "toggleButton", "expand" );
			}
			var hide = true;
			var bFrame = this.bodyFrame;
			if( bFrame != null && bFrame.iwpinfo != null )
				hide = bFrame.iwpinfo.locked;
			this.setImgButtonState( c, "toggleButton", "collapse", hide );
			this.swapImage( c.getElementById( "toggleButton" ), 0 );
			if( info == null && this.bodyFrame != null )
				info = this.bodyFrame.iwpinfo;
			if( info != null && info.locked )
				this.setImgButtonState( c, "toggleButton", "collapse", true );
		}
	}

	this.setupStatusFrame = function( frame )
	{
		if( frame != null && this.strings != null )
		{
			this.statusFrame = frame;
			var strs = this.strings;
			var sFrame = this.statusFrame;
			if( sFrame.document != null )
			{
				var s = sFrame.document;
				this.addOrReplaceTextNode( s, "modeBrowseBox", strs.stat_mode_browse );
				this.addOrReplaceTextNode( s, "modeFindBox", strs.stat_mode_find );
				this.addOrReplaceTextNode( s, "modeEditBox", strs.stat_mode_edit );
				this.addOrReplaceTextNode( s, "viewttlBox", strs.stat_lbl_viewas );
				this.addOrReplaceTextNode( s, "layttlBox", strs.stat_lbl_lay );
				this.addOrReplaceTextNode( s, "eprecordTxt", strs.stat_lbl_rec );
				this.addOrReplaceTextNode( s, "epfoundTxt", strs.stat_lbl_found );
				this.addOrReplaceTextNode( s, "eptotalTxt", strs.stat_lbl_total );
				this.addOrReplaceTextNode( s, "recordSpan", strs.stat_lbl_rec );
				this.addOrReplaceTextNode( s, "requestSpan", strs.stat_lbl_req );
				this.addOrReplaceTextNode( s, "requestsTxt", strs.stat_lbl_totreq );
				this.addOrReplaceTextNode( s, "currecBox", strs.stat_lbl_currec );
				this.addOrReplaceTextNode( s, "totalTxt", strs.stat_lbl_total );
				this.addOrReplaceTextNode( s, "foundTxt", strs.stat_lbl_found );
				this.addOrReplaceTextNode( s, "scriptSpan", strs.stat_lbl_script );
				this.addOrReplaceTextNode( s, "omitTxtBox", strs.stat_lbl_omit );
				this.setAltAttributes( s, "homeButton", strs.stat_hlp_home );
				this.setAltAttributes( s, "browseButton", strs.stat_hlp_browse );
				this.setAltAttributes( s, "findButton", strs.stat_hlp_find );
				this.setAltAttributes( s, "helpButton", strs.stat_hlp_help );
				this.setAltAttributes( s, "resetButton", strs.stat_hlp_undoedit );
				this.setAltAttributes( s, "resetFindButton", strs.stat_hlp_undofind );
				this.setAltAttributes( s, "newButton", strs.stat_hlp_new );
				this.setAltAttributes( s, "editButton", strs.stat_hlp_edit );
				this.setAltAttributes( s, "noeditButton", strs.stat_hlp_noedit );
				this.setAltAttributes( s, "dupButton", strs.stat_hlp_dup );
				this.setAltAttributes( s, "deleteButton", strs.stat_hlp_del );
				this.setAltAttributes( s, "sortButton", strs.stat_hlp_sort );
				this.setAltAttributes( s, "showallButton", strs.stat_hlp_all );
				this.setAltAttributes( s, "downButton", strs.stat_hlp_show );
				this.setAltAttributes( s, "upButton", strs.stat_hlp_hide );
				this.setAltAttributes( s, "omitButton", strs.stat_hlp_omit );
				this.setAltAttributes( s, "omitmultiButton", strs.stat_hlp_omitmulti );
				this.setAltAttributes( s, "showomitButton", strs.stat_hlp_showomit );
				this.setAltAttributes( s, "symbolpopup", strs.stat_pop_syms );
				this.setAltAttributes( s, "goRecButton", strs.stat_hlp_go );
				this.setAltAttributes( s, "goReqButton", strs.stat_hlp_goreq );
				this.setAltAttributes( s, "reqnumField", strs.stat_hlp_cureq );
				this.setAltAttributes( s, "recnumField", strs.stat_hlp_curec );
				this.setAltAttributes( s, "prevButton", strs.stat_hlp_prev );
				this.setAltAttributes( s, "prevFindButton", strs.stat_hlp_prevreq );
				this.setAltAttributes( s, "prevMultiButton", strs.stat_hlp_prevmulti );
				this.setAltAttributes( s, "nextButton", strs.stat_hlp_next );
				this.setAltAttributes( s, "nextFindButton", strs.stat_hlp_nextreq );
				this.setAltAttributes( s, "nextMultiButton", strs.stat_hlp_nextmulti );
				this.setAltAttributes( s, "refindButton", strs.stat_hlp_refind );
				this.setAltAttributes( s, "newReqButton", strs.stat_hlp_newreq );
				this.setAltAttributes( s, "dupReqButton", strs.stat_hlp_dupreq );
				this.setAltAttributes( s, "delReqButton", strs.stat_hlp_delreq );
				this.setAltAttributes( s, "showallButton2", strs.stat_hlp_all );
				this.setAltAttributes( s, "submitButton", strs.stat_hlp_submit );
				this.setAltAttributes( s, "cancelButton", strs.stat_hlp_cancel );
				this.setupRollover( s, "homeButton", "home" + ( this.isEnglish ? "" : "2" ) );
				this.setupRollover( s, "browseButton", "browse" + ( this.isEnglish ? "" : "2" ) );
				this.setupRollover( s, "findButton", "find" + ( this.isEnglish ? "" : "2" ) );
				this.setupRollover( s, "helpButton", "help" );
				this.setupRollover( s, "resetButton", "undo" );
				this.setupRollover( s, "resetFindButton", "undo" );
				this.setupRollover( s, "newButton", "new" );
				this.setupRollover( s, "editButton", "edit" );
				this.setupRollover( s, "noeditButton", "noedit" );
				this.setupRollover( s, "dupButton", "dup" );
				this.setupRollover( s, "deleteButton", "delete" );
				this.setupRollover( s, "sortButton", "sort" );
				this.setupRollover( s, "showallButton", "showall" );
				this.setupRollover( s, "downButton", "down" );
				this.setupRollover( s, "upButton", "up" );
				this.setupRollover( s, "newReqButton", "newreq" );
				this.setupRollover( s, "dupReqButton", "dupreq" );
				this.setupRollover( s, "delReqButton", "delreq" );
				this.setupRollover( s, "showallButton2", "showall" );
				this.setupRollover( s, "omitButton", "omit" );
				this.setupRollover( s, "omitmultiButton", "omitmulti" );
				this.setupRollover( s, "showomitButton", "showomit" );
				this.setupRollover( s, "goRecButton", "go" );
				this.setupRollover( s, "goReqButton", "go" );
				this.setupRollover( s, "prevButton", "previous" );
				this.setupRollover( s, "prevFindButton", "previous" );
				this.setupRollover( s, "prevMultiButton", "previous" );
				this.setupRollover( s, "nextButton", "next" );
				this.setupRollover( s, "nextFindButton", "next" );
				this.setupRollover( s, "nextMultiButton", "next" );
				this.setupRollover( s, "refindButton", "refind" );
				this.setValue( s, "submitButton", strs.stat_btn_submit );
				this.setValue( s, "submitButton", strs.stat_btn_submit );
				this.setValue( s, "cancelButton", strs.stat_btn_cancel );
				this.setValue( s, "contScriptButton", strs.stat_btn_cont );
				this.setValue( s, "cancelScriptButton", strs.stat_btn_cancel );
				this.setValue( s, "logoutButton", strs.stat_btn_logout );
				this.setValue( s, "performFindButton", strs.stat_lbl_pfind );
				this.setValue( s, "extendFindButton", strs.stat_lbl_efind );
				this.setValue( s, "constrainFindButton", strs.stat_lbl_cfind );

				var obj = s.getElementById("symbolpopup");
				if( obj != null && obj.options != null )
				{
					obj.options[0] = new sFrame.Option( strs.stat_pop_syms );
					obj.options[1] = new sFrame.Option( "< " + strs.stat_pop_lt, "<" );
					obj.options[2] = new sFrame.Option( "<= " + strs.stat_pop_lte, "<=" );
					obj.options[3] = new sFrame.Option( "> " + strs.stat_pop_gt, ">" );
					obj.options[4] = new sFrame.Option( ">= " + strs.stat_pop_gte, ">=" );
					obj.options[5] = new sFrame.Option( "= " + strs.stat_pop_equ, "=" );
					obj.options[6] = new sFrame.Option( "... " + strs.stat_pop_range, "..." );
					obj.options[7] = new sFrame.Option( "! " + strs.stat_pop_dups, "!" );
					obj.options[8] = new sFrame.Option( "// " + strs.stat_pop_today, "//" );
					obj.options[9] = new sFrame.Option( "? " + strs.stat_pop_inval, "?" );
					obj.options[10] = new sFrame.Option( "@ " + strs.stat_pop_one, "@" );
					obj.options[11] = new sFrame.Option( "* " + strs.stat_pop_zero, "*" );
					obj.options[12] = new sFrame.Option( '"" ' + strs.stat_pop_liter, '""' );
					obj.options[13] = new sFrame.Option( "~ " + strs.stat_pop_relax, "~" );
					obj.options[14] = new sFrame.Option( "== " + strs.stat_pop_cont, "==" );
					obj.options[0].selected = true;
				}
				
				this.setImgButtonState( s, "homeButton", "home" + ( this.isEnglish ? "" : "2" ), true );
				this.setImgButtonState( s, "browseButton", "browse" + ( this.isEnglish ? "" : "2" ), true );
				this.setImgButtonState( s, "findButton", "find" + ( this.isEnglish ? "" : "2" ), true );
				this.updateStatusFrame();
			}
		}
	}
	
	this.setupTopFrame = function( statVis, isEng )
	{
		if( this.strings != null && statVis != null && isEng != null )
		{
			this.statusVisible = statVis;
			this.isEnglish = isEng;
			if( document != null )
				document.title = this.strings.home_ttl_iwp;
		}
	}
	
	this.updateNavPanel = function( win, info, strs )
	{
		if( win != null && info != null && strs != null )
		{
			var obj = null;
			var doc = win.document;
			if( doc != null )
				obj = doc.getElementById("laypopup");
			if( obj != null && obj.options != null )
			{
				var opts = obj.options;
				var lays = info.layouts;
				var index = lays[0];
				opts.length = 0;
				for( var i = 1; i < lays.length; ++i, ++index )
				{
					var opt = new win.Option(lays[i], index );
					opts[i-1] = opt;
				}
				index = 0;
				if( info.lay > 0 )
					index = info.lay - lays[0];
				opts[index].selected = true;
			}
	
			if( doc != null )
				obj = doc.getElementById("viewpopup");
			if( obj != null && obj.options != null )
			{
				var opts = obj.options;
				opts.length = 0;
				if( info.formviewenabled )
					opts[opts.length] = new win.Option(strs.stat_pop_form,"form");
				if( info.listviewenabled )
					opts[opts.length] = new win.Option(strs.stat_pop_list,"list");
				if( info.tableviewenabled )
					opts[opts.length] = new win.Option(strs.stat_pop_table,"table");
	
				for( var i = 0; i < opts.length; ++i )
				{
					var opt = opts[i];
					if( opt.value == info.viewas )
					{
						opt.selected = true;
						break;
					}
				}
			}
			
			if( info.viewas == "form" )
				this.setObjVisibility( doc, "rangeBox", false );
			else
			{
				var rangemax;
				var end = info.recnum + info.pagesize - 1;
				if( info.mode == this.findMode )
					rangemax = info.total;
				else
					rangemax = info.found;
				if( end > rangemax )
					end = rangemax;
				this.addOrReplaceTextNode( doc, "rangeLeft", info.recnum, 0 );
				this.addOrReplaceTextNode( doc, "rangeRight", end, 0 );
				this.setObjVisibility( doc, "rangeBox", true );
			}
		}
	}
	
	this.setToobarState = function( doc, info, disable )
	{
		if( doc != null && info != null && disable  != null )
		{
			if( info.cannew )
				this.setImgButtonState( doc, "newButton", "new", disable );
			else
				this.setImgButtonState( doc, "newButton", "new", true );
			if( info.canedit && info.recnum > 0 )
				this.setImgButtonState( doc, "editButton", "edit", disable );
			else
				this.setImgButtonState( doc, "editButton", "edit", true );
			this.setImgButtonState( doc, "noeditButton", "noedit", disable );
			if( info.cannew && info.recnum > 0 )
				this.setImgButtonState( doc, "dupButton", "dup", disable );
			else
				this.setImgButtonState( doc, "dupButton", "dup", true );
			if( info.candelete && info.recnum > 0 )
				this.setImgButtonState( doc, "deleteButton", "delete", disable );
			else
				this.setImgButtonState( doc, "deleteButton", "delete", true );
			this.setImgButtonState( doc, "sortButton", "sort", disable || info.found == 0 );
			this.setImgButtonState( doc, "showallButton", "showall", disable || info.total == 0 );
			this.setObjVisibility( doc, "downBox", ! disable && info.recnum > 0 );
		}
	}
	
	this.updateStatusFrame = function( win )
	{
		if( win != null )
			this.bodyFrame = win;
		var bFrame = this.bodyFrame;
		if( bFrame != null && bFrame.iwpinfo != null )
		{
			var info = bFrame.iwpinfo;
			if( this.statusVisible != info.visible )
			{
				var url = this.cgiPath()
				if( url != null )
				{
					url += "-db=" + info.db.url + "&-loadframes";
					window.location = url;
					return;
				}
			}
			this.setupControlFrame( this.controlFrame, info );
			this.openUrlWindows( info.urls );
			if( ! this.statusVisible )
				return;
			var sFrame = this.statusFrame;
			if( sFrame != null && sFrame.document != null && this.strings != null )
			{
				var s = sFrame.document;
				var strs = this.strings;
				this.setObjVisibility( s, "statusBox", true );
				this.setObjVisibility( s, "moveBox", true );
				if( info.debug != null )
					this.setObjVisibility( s, "debugBox", true );
				if( info.mode == this.findMode )
				{
					this.setObjVisibility( s, "resetBox", false );
					this.setObjVisibility( s, "statusBox", false );
					this.setObjVisibility( s, "modeBrowseBox", false );
					this.setObjVisibility( s, "modeEditBox", false );
					this.setObjVisibility( s, "toolBox", false );
					this.setObjVisibility( s, "toolBox2", false );
					this.setObjVisibility( s, "editBox", false );
					this.setObjVisibility( s, "downBox", false );
					this.setObjVisibility( s, "submitPanel", false );
					this.setObjVisibility( s, "editPanel", false );
					this.setObjVisibility( s, "browsePanel", false );
					this.setObjVisibility( s, "prevBox", false );
					this.setObjVisibility( s, "nextBox", false );
					this.setObjVisibility( s, "prevMultiBox", false );
					this.setObjVisibility( s, "nextMultiBox", false );
					this.setObjVisibility( s, "refindBox", false );
					this.updateNavPanel( sFrame, info, strs );
					this.setImgButtonState( s, "homeButton", "home" + ( this.isEnglish ? "" : "2" ), false );
					this.setImgButtonState( s, "browseButton", "browse" + ( this.isEnglish ? "" : "2" ), false );
					this.setImgButtonState( s, "findButton", "find" + ( this.isEnglish ? "" : "2" ), true );
					this.setImgButtonState( s, "resetFindButton", "undo", false );
					this.setImgButtonState( s, "prevFindButton", "previous", info.recnum <= 1 );
					this.setImgButtonState( s, "nextFindButton", "next", info.recnum == info.total );
					this.setImgButtonState( s, "delReqButton", "delreq", info.total <= 1 );
					this.setValue( s, "reqnumField", info.recnum );
					var obj = s.getElementById("omitCheckbox");
					if( obj != null )
						obj.checked = info.omitstate
					this.addOrReplaceTextNode( s, "requestsNum", info.total, 0 );
					var moveBox = s.getElementById( "moveBox" );
					if( moveBox != null && this.positions.currentTop == null )
						this.positions.currentTop = moveBox.style.top;
					this.setTop( s, "moveBox", 71 );
					this.setTop( s, "buttonPanel", 360 );
					this.setObjVisibility( s, "statusBox", true );
					this.setObjVisibility( s, "modeFindBox", true );
					this.setObjVisibility( s, "findToolBox", true );
					this.setObjVisibility( s, "navPanel", true );
					this.setObjVisibility( s, "findPanel", true );
					this.setObjVisibility( s, "logoutBox", true );
					this.setObjVisibility( s, "resetFindBox", true );
					this.setObjVisibility( s, "prevFindBox", true );
					this.setObjVisibility( s, "nextFindBox", true );
				}
				else if( info.mode != this.browseMode && info.confirm )
				{
					this.setObjVisibility( s, "resetFindBox", false );
					this.setObjVisibility( s, "statusBox", false );
					this.setObjVisibility( s, "modeFindBox", false );
					this.setObjVisibility( s, "modeBrowseBox", false );
					this.setObjVisibility( s, "toolBox2", false );
					this.setObjVisibility( s, "findToolBox", false );
					this.setObjVisibility( s, "navPanel", false );
					this.setObjVisibility( s, "findPanel", false );
					this.setObjVisibility( s, "browsePanel", false );
					this.setObjVisibility( s, "logoutBox", false );
					this.setObjVisibility( s, "noeditBox", false );
					this.setObjVisibility( s, "prevBox", false );
					this.setObjVisibility( s, "nextBox", false );
					this.setObjVisibility( s, "prevFindBox", false );
					this.setObjVisibility( s, "nextFindBox", false );
					this.setObjVisibility( s, "prevMultiBox", false );
					this.setObjVisibility( s, "nextMultiBox", false );
					this.setObjVisibility( s, "refindBox", false );
					this.setImgButtonState( s, "homeButton", "home" + ( this.isEnglish ? "" : "2" ), true );
					this.setImgButtonState( s, "browseButton", "browse" + ( this.isEnglish ? "" : "2" ), true );
					this.setImgButtonState( s, "findButton", "find" + ( this.isEnglish ? "" : "2" ), true );
					this.addOrReplaceTextNode( s, "eprecordNum", info.recnum, 0 );
					this.addOrReplaceTextNode( s, "epfoundNum", info.found, 0 );
					this.addOrReplaceTextNode( s, "eptotalNum", info.total, 0 );
					var moveBox = s.getElementById( "moveBox" );
					if( moveBox != null && this.positions.currentTop == null )
						this.positions.currentTop = moveBox.style.top;
					this.setTop( s, "moveBox", 71 );
					this.setTop( s, "buttonPanel", 269 );
					this.setToobarState( s, info, true );
					this.setImgButtonState( s, "resetButton", "undo", false );
					this.setObjVisibility( s, "statusBox", true );
					this.setObjVisibility( s, "editBox", true );
					this.setObjVisibility( s, "modeEditBox", true );
					this.setObjVisibility( s, "toolBox", true );
					this.setObjVisibility( s, "submitPanel", true );
					this.setObjVisibility( s, "editPanel", true );
					this.setObjVisibility( s, "resetBox", true );
				}
				else
				{
					this.setObjVisibility( s, "resetFindBox", false );
					this.setObjVisibility( s, "statusBox", false );
					this.setObjVisibility( s, "modeFindBox", false );
					this.setObjVisibility( s, "modeEditBox", false );
					this.setObjVisibility( s, "findToolBox", false );
					this.setObjVisibility( s, "submitPanel", false );
					this.setObjVisibility( s, "editPanel", false );
					this.setObjVisibility( s, "findPanel", false );
					this.setObjVisibility( s, "prevFindBox", false );
					this.setObjVisibility( s, "nextFindBox", false );
					this.updateNavPanel( sFrame, info, strs );
					this.setValue( s, "recnumField", info.recnum );
					this.setImgButtonState( s, "homeButton", "home" + ( this.isEnglish ? "" : "2" ), false );
					this.setImgButtonState( s, "browseButton", "browse" + ( this.isEnglish ? "" : "2" ), true );
					this.setImgButtonState( s, "findButton", "find" + ( this.isEnglish ? "" : "2" ), info.total == 0 || ! info.canfind );
					this.setObjVisibility( s, "refindBox", info.total > 0 && info.canfind );
					var prev = strs.stat_hlp_prev;
					var next = strs.stat_hlp_next;
					var sortState = strs.stat_lbl_unsort;
					if( info.sorted )
						sortState = strs.stat_lbl_sort;
					this.addOrReplaceTextNode( s, "sortStateBox", sortState, 0 );
					this.addOrReplaceTextNode( s, "totalNum", info.total, 0 );
					this.addOrReplaceTextNode( s, "foundNum", info.found, 0 );
					var moveBox = s.getElementById( "moveBox" );
					if( moveBox != null && this.positions.currentTop != null )
					{
						this.setTop( s, "moveBox", this.positions.currentTop  );
						this.positions.currentTop = null;
					}
					this.setTop( s, "buttonPanel", 269 );
					this.setObjVisibility( s, "statusBox", true );
					this.setObjVisibility( s, "modeBrowseBox", true );
					this.setToobarState( s, info, false );
					this.setObjVisibility( s, "toolBox", true );
					var noedit = false;
					if( info.mode != this.browseMode )
						noedit = true;
					this.setObjVisibility( s, "noeditBox", noedit );
					this.setObjVisibility( s, "editBox", ! noedit );
					this.setImgButtonState( s, "resetButton", "undo", ! noedit );
					obj = s.getElementById("toolBox2");
					if( obj != null )
					{
						var vis = this.positions.visible;
						if(  vis == null )
							vis =  false;
						this.setObjVisibility( s, "toolBox2", vis && info.total );
						this.setObjVisibility( s, "downBox", ! vis && info.total );
					}
					this.setObjVisibility( s, "navPanel", true );
					this.setObjVisibility( s, "browsePanel", true );
					this.setObjVisibility( s, "logoutBox", true );
					this.setObjVisibility( s, "resetBox", true );
					var isForm = ( info.viewas == "form" );
					this.setObjVisibility( s, "prevBox", isForm );
					this.setObjVisibility( s, "nextBox", isForm );
					this.setObjVisibility( s, "prevMultiBox", ! isForm );
					this.setObjVisibility( s, "nextMultiBox", ! isForm );	
					if( isForm )
					{
						this.setImgButtonState( s, "prevButton", "previous", info.recnum <= 1 );
						this.setImgButtonState( s, "nextButton", "next", info.recnum == info.found );
					}
					else
					{
						var min = 5;
						if( info.viewas == "table" )
							min = 20;
						this.setImgButtonState( s, "prevMultiButton", "previous", info.recnum <= 1 );
						this.setImgButtonState( s, "nextMultiButton", "next", info.found < ( info.recnum + min) );
					}
			
				}
				this.setObjVisibility( s, "scriptBox", info.paused );
				document.title = info.windowtitle;
			}
		}
	}

	/***** event methods *****************************************/

	this.focusActiveField = function()
	{
		var bFrame = this.bodyFrame;
		if( bFrame != null && bFrame.document != null && bFrame.document.activeField != null )
		{
			bFrame.document.activeField.focus();
			bFrame.focus();
		}
	}
	
	this.focusFirstField = function()
	{
		var bFrame = this.bodyFrame;
		if( bFrame != null && bFrame.document != null )
		{
			var fld = bFrame.document.getElementById( "active" );
			if( fld != null )
				fld.focus();
		}
	}
	
	this.handleBlur = function( obj )
	{
	}

	this.handleFocus = function( obj )
	{
		if( obj != null )
		{
			var bFrame = this.bodyFrame;
			if( bFrame != null && bFrame.document != null && bFrame.iwpinfo != null )
			{
				if( bFrame.iwpinfo.mode == this.findMode )
				{
					bFrame.document.activeField = obj;
					var sFrame = this.statusFrame;
					if( sFrame != null && sFrame.document != null )
					{
						var sym = sFrame.document.getElementById( "symbolpopup" );
						sym.disabled = false;
					}
				}
			}
		}
	}
	
	this.handleLoad = function()
	{
		var bFrame = this.bodyFrame
		if( bFrame != null )
		{
			if( ! this.isSafari10 )
				bFrame.history.forward();
		}
		this.focusFirstField();
	}
		
	this.handleUnload = function()
	{
	}

	/***** action methods *****************************************/
	
	this.deleteNow = function()
	{
		var bFrame = this.bodyFrame;
		var path = this.cgiPath();
		if( bFrame != null && bFrame.iwpinfo != null && path != null )
			bFrame.location = path + "-recid=" + bFrame.iwpinfo.currecid + "&-delete";
	}

	this.deleteRecord = function()
	{
		var sf = this.statusFrame;
		if( sf != null )
		{
			var obj = sf.document.getElementById("deleteButton");
			if( obj != null && this.objectEnabled( obj ) )
			{
				if( this.strings != null && confirm(this.strings.stat_ask_del) )
					this.deleteNow();
			}
		}
	}
	
	this.deleteRequest = function()
	{
		var sf = this.statusFrame;
		if( sf != null )
		{
			var obj = sf.document.getElementById("delReqButton");
			if( obj != null && this.objectEnabled( obj ) )
				this.deleteNow();
		}
	}

	this.duplicateRecordOrRequest = function( obj )
	{
		if( obj != null && this.objectEnabled( obj ) )
			this.submitAndContinue( [{target: "-submitclose", n: "-duplicate", v: ""}] );
	}

	this.duplicateRecord = function()
	{
		var sf = this.statusFrame;
		if( sf != null )
		{
			var obj = sf.document.getElementById("dupButton");
			this.duplicateRecordOrRequest( obj );
		}
	}

	this.duplicateRequest = function()
	{
		var sf = this.statusFrame;
		if( sf != null )
		{
			var obj = sf.document.getElementById("dupReqButton");
			this.duplicateRecordOrRequest( obj );
		}
	}

	this.editCancel = function()
	{
		var bFrame = this.bodyFrame;
		var path = this.cgiPath();
		if( bFrame != null && path != null )
			bFrame.location = path + "-canceledit";
	}
	
	this.editRecord = function()
	{
		var sf = this.statusFrame;
		if( sf != null )
		{
			var obj = sf.document.getElementById("editButton");
			if( obj != null && this.objectEnabled( obj ) )
				this.submitAndContinue( [{target: "-submitclose", n: "-edit", v: ""}] );
		}
	}
	
	this.editRecById = function( recordID, activeobject, field, repetition, portalrow )
	{
		var bf = this.bodyFrame;
		if(	recordID != null
			&& recordID > 0
			&& activeobject != null
			&& bf != null
			&& bf.iwpinfo != null
			&& ( ! bf.iwpinfo.confirm || ( bf.iwpinfo.mode == this.findMode || bf.iwpinfo.mode == this.browseMode ) ) )
		{
			var args = new Array();
			if( bf.iwpinfo.mode == this.browseMode && field != null && field.hasChildNodes() )
			{
				var nodes = field.childNodes;
				if( nodes.length )
				{
					var isCheck = false;
					/*for( var i = 0; i < nodes.length; ++i )
					{
						var type = nodes[i].type;
						if( type == "checkbox" )
							isCheck = true;
						if( ( ( type == "radio" ) || ( type == "checkbox" ) ) && nodes[i].checked )
						{
							alert("setting name/value: " + nodes[i].name + "/" + nodes[i].value);
							args[args.length] = {target: "-field", n: nodes[i].name, v: nodes[i].value};
						}
					}
					if( isCheck )
						args[args.length] = {target: null, n: nodes[0].name, v: ""};*/
					if( nodes[0].type == "checkbox" )
						args[args.length] = {target: "-field", n: nodes[0].name, v: ""};
				}
			}
			
		//	add the repetition number
			args[args.length] = {target: "-repetition", n: "-repetition", v: repetition};
		
		//	add the portal row
			args[args.length] = {target: "-portalrow", n: "-portalrow", v: portalrow};
					
			this.submitAndContinue( args.concat( [{target: "-recid", n: "-recid", v: recordID},
				{target: "-index", n: "-index", v: activeobject}] ), null, "iwpedit" );
		}
	}

	this.submitData = function( obj, overRide )
	{
		if( obj != null )
		{
			if( overRide == null )
				overRide = false;
			bFrame = this.bodyFrame;
			if( bFrame != null && bFrame.iwpinfo != null )
			{
				if( ! bFrame.iwpinfo.confirm || ( overRide || this.objectEnabled( obj ) ) )
					this.submitAndContinue();
			}
		}
	}

	this.noeditSubmit = function()
	{
		var sf = this.statusFrame;
		if( sf != null )
		{
			var obj = sf.document.getElementById("noeditButton");
			this.submitData( obj );
		}
	}

	this.editSubmit = function( obj )
	{
		var sf = this.statusFrame;
		if( sf != null )
		{
			if( obj != null && obj.id == "submitButton" )
			{			
				var obj = sf.document.getElementById("submitButton");
				this.submitData( obj, true );
			}
		}
	}

	this.findOmitted = function()
	{
		this.submitAndContinue( [{target: "-submitclose", n: "-findomitted", v: ""}] );
	}
	
	this.insertSymbol = function( obj )
	{
		var bFrame = this.bodyFrame;
		if( obj != null && bFrame != null && bFrame.document != null )
		{
			var fld = bFrame.document.activeField;
			if( fld != null )
			{
				var sel = obj.selectedIndex;
				obj.selectedIndex = 0;
				if( sel > 0 && sel < obj.options.length )
				{
					var sym = obj.options[sel].value;
					fld.value = fld.value + sym;
				}
			}
		}
	}

	this.logOut = function( target )
	{
		this.submitAndContinue( [{target: "-submitclose", n: "-close", v: ""}], "_top" );
	}
	
	this.newRecordOrRequest = function( obj )
	{
		if( obj != null && this.objectEnabled( obj ) )
			this.submitFindRequest( [{target: "-submitclose", n: "-new", v: ""}] );
	}
	
	this.newRecord = function()
	{
		var sf = this.statusFrame;
		if( sf != null )
		{
			var obj = sf.document.getElementById("newButton");
			this.newRecordOrRequest( obj );
		}
	}
	
	this.newRequest = function()
	{
		var sf = this.statusFrame;
		if( sf != null )
		{
			var obj = sf.document.getElementById("newReqButton");
			this.newRecordOrRequest( obj );
		}
	}
	
	this.omitMultiple = function( def )
	{
		var strs = this.strings;
		if( strs != null )
		{
			if( def == null )
				def = "1";
			var num = prompt( strs.stat_ask_omit, def );
			if( ! isNaN(num) && num > 0 )
				this.submitAndContinue( [{target: "-omitstate", n: "-count", v: num},{target: "-submitclose", n: "-omitmultiple", v: ""}] );
			else if( num != null )
			{
				alert(strs.stat_err_omit);
				this.omitMultiple( num );
			}
		}
	}
	
	this.omitSingle = function()
	{
		this.submitFindRequest( [{target: "-submitclose", n: "-omit", v: ""}] );
	}
	
	this.performFind = function( type )
	{
		var args = new Array();
		if( type != null && type > 0 )
		{
			var val = "extend";
			if( type > 1 )
				val = "constrain";
			args[0] = {target: "-type", n: "-type", v: val};
		}
		this.submitFindRequest( args );
	}
	
	this.resetForm = function( obj )
	{
		if( obj != null && this.objectEnabled( obj ) )
		{
			var bFrame = this.bodyFrame;
			if( bFrame != null && bFrame.document != null )
			{
				var frm = bFrame.document.getElementById( "iwpform" );
				if( frm != null )
				{
					frm.reset();
				}
			}
		}
	}
	
	this.resetEditForm = function()
	{
		var sf = this.statusFrame;
		if( sf != null )
		{
			var obj = sf.document.getElementById("resetButton");
			this.resetForm( obj );
		}
	}
	
	this.resetFindForm = function()
	{
		var sf = this.statusFrame;
		if( sf != null )
		{
			var obj = sf.document.getElementById("resetFindButton");
			this.resetForm( obj );
		}
 	}
	
	this.scriptCancel = function()
	{
		this.submitFindRequest( [{target: "-submitclose", n: "-exitscript", v: ""}] );
	}
	
	this.scriptContinue = function()
	{
		this.submitFindRequest( [{target: "-submitclose", n: "-resumescript", v: ""}] );
	}
	
	this.showAllRecordsOrRequests = function( obj )
	{
		if( obj != null && this.objectEnabled( obj ) )
			this.submitFindRequest( [{target: "-submitclose", n: "-showall", v: ""}] );
	}
	
	this.showAllRecords = function()
	{
		var sf = this.statusFrame;
		if( sf != null )
		{
			var obj = sf.document.getElementById("showallButton");
			this.showAllRecordsOrRequests( obj );
		}
	}

	this.showAllRequests = function()
	{
		var sf = this.statusFrame;
		if( sf != null )
		{
			var obj = sf.document.getElementById("showallButton2");
			this.showAllRecordsOrRequests( obj );
		}
	}
	
	this.sortTableByFieldName = function( index )
	{
		var bf = this.bodyFrame;
		if( index != null && bf != null && bf.iwpinfo != null )
		{
			var info = bf.iwpinfo;
			if( ! info.confirm || ( info.mode == this.findMode || info.mode == this.browseMode ) )
			{
				var order = "ascend";
				if( info.sorted && index == info.currentorder.index && info.currentorder.order == order )
					order = "descend";
				this.submitFindRequest( [{target: "-type", n: "-sortfield.1", v: index},{target: "-omitstate", n: "-sortorder.1", v: order},{target: "-submitclose", n: "-iwpsort", v: ""}] );
			}
		}
	}

	/***** navigation methods *****************************************/

	this.goHome = function()
	{
		var sf = this.statusFrame;
		if( sf != null )
		{
			var obj = sf.document.getElementById("homeButton");
			if( obj != null && this.objectEnabled( obj ) )
				this.submitAndContinue( [{target: "-submitclose", n: "-home", v: ""}], "_top" );
		}
	}
	
	this.goToBrowse = function()
	{
		var sf = this.statusFrame;
		if( sf != null )
		{
			var obj = sf.document.getElementById("browseButton");
			if( obj != null && this.objectEnabled( obj ) )
				this.submitAndContinue( [{target: "-submitclose", n: "-browse", v: ""}] );
		}
	}
	
	this.goToFind = function( obj )
	{
		var sf = this.statusFrame;
		if( sf != null )
		{
			var obj = sf.document.getElementById("findButton");
			if( obj != null && this.objectEnabled( obj ) )
				this.submitAndContinue( [{target: "-submitclose", n: "-find", v: ""}] );
		}
	}

	this.goToLayout = function( sel )
	{
		if( sel != null && sel.options != null )
		{
			var layID = sel.options[sel.selectedIndex].value;
			this.submitAndContinue( [{target: "-type", n: "-lay", v: layID},{target: "-submitclose", n: "-gotolayout", v: ""}] );
		}
	}
		
	this.goToNext = function( obj )
	{
		if( obj != null && this.objectEnabled( obj ) )
			this.submitAndContinue( [{target: "-submitclose", n: "-next", v: ""}] );
	}

	this.goToNextSingle = function()
	{
		var sf = this.statusFrame;
		if( sf != null )
		{
			var obj = sf.document.getElementById("nextButton");
			this.goToNext( obj );
		}
	}

	this.goToNextFind = function()
	{
		var sf = this.statusFrame;
		if( sf != null )
		{
			var obj = sf.document.getElementById("nextFindButton");
			this.goToNext( obj );
		}
	}

	this.goToNextMulti = function()
	{
		var sf = this.statusFrame;
		if( sf != null )
		{
			var obj = sf.document.getElementById("nextMultiButton");
			this.goToNext( obj );
		}
	}

	this.goToPrevious = function( obj )
	{
		if( obj != null && this.objectEnabled( obj ) )
			this.submitAndContinue( [{target: "-submitclose", n: "-prev", v: ""}] );
	}

	this.goToPrevSingle = function()
	{
		var sf = this.statusFrame;
		if( sf != null )
		{
			var obj = sf.document.getElementById("prevButton");
			this.goToPrevious( obj );
		}
	}

	this.goToPrevFind = function()
	{
		var sf = this.statusFrame;
		if( sf != null )
		{
			var obj = sf.document.getElementById("prevFindButton");
			this.goToPrevious( obj );
		}
	}
	
	this.goToPrevMulti = function()
	{
		var sf = this.statusFrame;
		if( sf != null )
		{
			var obj = sf.document.getElementById("prevMultiButton");
			this.goToPrevious( obj );
		}
	}
	
	this.goToRecById = function( recordID )
	{
		var bf = this.bodyFrame;
		if( recordID != null && bf != null && bf.iwpinfo != null && ( ! bf.iwpinfo.confirm || ( bf.iwpinfo.mode == this.findMode || bf.iwpinfo.mode == this.browseMode ) ) )
			this.submitAndContinue( [{target: "-omitstate", n: "-recid", v: recordID},{target: "-submitclose", n: "-gotorecbyid", v: ""}] );
	}

	this.goToRecordNumber = function( objID )
	{
		var bFrame = this.bodyFrame;
		var sFrame = this.statusFrame;
		if( objID != null && bFrame != null && bFrame.iwpinfo != null && sFrame != null )
		{
			var obj = sFrame.document.getElementById(objID);
			if( obj != null )
			{
				var recNum = obj.value;
				if( isNaN(recNum) || recNum < 1 )
				{
					obj.value = bFrame.iwpinfo.recnum;
					return;
				}
				else if( bFrame.iwpinfo.found < recNum )
					recNum = bFrame.iwpinfo.found;
				this.submitAndContinue( [{target: "-omitstate", n: "-recordnumber", v: recNum},{target: "-submitclose", n: "-goto", v: ""}] );
			}
		}
	}

	this.goToRefind = function()
	{
		this.submitAndContinue( [{target: "-submitclose", n: "-refind", v: ""}] );
	}
	
	this.goToView = function( sel )
	{
		if( sel != null && sel.selectedIndex != null )
		{
			var i = sel.selectedIndex;
			if( i != -1 )
			{
				var view = sel.options[i].value;
				var action = "-formview";
				if( view == "list" )
					action = "-listview";
				else if( view == "table" )
					action = "-tableview";
				this.submitAndContinue( [{target: "-submitclose", n: action, v: ""}] );
			}
		}
	}
	
	this.openHelpWindow = function( anchor )
	{
		if( anchor == null )
		{
			anchor = "Table_of_contents";
			var bFrame = this.bodyFrame;
			if( bFrame != null && bFrame.iwpinfo != null )
			{
				var info = bFrame.iwpinfo;
				if( info.mode == this.browseMode )
					anchor = "Navigating_records";
				else if( info.mode == this.editMode )
					anchor = "Editing_records";
				else if( info.mode == this.newMode )
					anchor = "Adding_data";
				else if( info.mode == this.findMode )
					anchor = "Finding_records";
			}
		}
		var win = window.open("/fmi/iwp/cgi?-gethelp&-anchor=" + anchor,"IWPHelp","top=20,left=20,height=460,width=620,fullscreen=no,location=no,menubar=no,resizable=yes,scrollbars=yes,status=no,toolbar=no");
	}
	
	this.openSortDlog = function()
	{
		var sf = this.statusFrame;
		if( sf != null )
		{
			var obj = sf.document.getElementById("sortButton");
			if( obj != null && this.objectEnabled( obj ) )
			{
				this.editSubmit();
				var url = this.cgiPath();
				if( url != null )
				{
					url += "-opensort";
					var win = window.open(url,"iwp_sort","alwaysraised=yes,dependent=yes,top=20,left=20,height=265,width=512,location=no,menubar=no,directories=no,resizable=no,scrollbars=no,status=no,toolbar=no,titlebar=no");
				}
			}
		}
	}
				
	this.openInNewWindow = function( url )
	{
		if( url != null )
		{
			var winName = "iwp_" + this.winCounter++;
			var win = window.open(url,winName,"alwaysraised=yes,dependent=yes,top=20,left=20,height=265,width=512,location=no,menubar=no,directories=no,resizable=no,scrollbars=no,status=no,toolbar=no,titlebar=no");
		}
	}

	// gloabals
	this.isSafari10		=	this.checkForSafari10();
	this.browseMode		=	"browse";
	this.editMode		=	"edit";
	this.newMode		=	"new";
	this.findMode		=	"find";
	this.statusVisible	=	false;
	this.imgPath		=	"/fmi/iwp/res/images/";
	this.objstate		=	new Object();
	this.positions		=	new Object();
	this.debugurl		=	false;
	this.winCounter		=	0;
}

// Create Objects

if ( window.iwp == null )
	window.iwp = new IWPObj();
