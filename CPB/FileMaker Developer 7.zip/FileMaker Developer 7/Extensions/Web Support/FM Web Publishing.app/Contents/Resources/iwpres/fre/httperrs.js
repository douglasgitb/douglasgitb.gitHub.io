/*===================================================================================

  copyright: (C) Copyright 2003-2004 Filemaker, Inc. All Rights Reserved
  
  =================================================================================*/

window.errs = {
	http:		true,
	e_200_0:	"OK\r\rPas d'erreur.",
	e_204_0:	"Aucun enregistrement trouvé\r\rAucun enregistrement ne correspond aux critères de recherche.",
	e_400_0:	"Requête incorrecte\r\rLe serveur n'a pas pu traiter votre requête en raison d'une erreur de syntaxe.",
	e_400_1:	"Requête incorrecte\r\rLe serveur n'a pas pu traiter votre requête en raison d'une URL erronée.",
	e_400_2:	"Requête incorrecte\r\rLe serveur n'a pas pu traiter votre requête en raison d'un paramètre manquant. \"^1\".",
	e_400_3:	"Requête incorrecte\r\rLe serveur n'a pas pu traiter votre requête en raison d'une rubrique vide. \"^1\".",
	e_400_4:	"Requête incorrecte\r\rLe serveur n'a pas pu traiter votre requête en raison d'un paramètre interdit.  \"^1\".",
	e_400_5:	"Requête incorrecte\r\rLe serveur n'a pas pu traiter votre requête en raison d'un paramètre obsolète. \"^1\".",
	e_400_6:	"Requête incorrecte\r\rLe serveur n'a pas pu traiter votre requête en raison d'une commande manquante. \"^1\".",
	e_400_7:	"Requête incorrecte\r\rLe serveur n'a pas pu traiter votre requête en raison d'un conflit de commandes.",
	e_400_8:	"Requête incorrecte\r\rLe serveur n'a pas pu traiter votre requête en raison d'une spécification de base de données manquante.",
	e_400_9:	"Requête incorrecte\r\rLe serveur n'a pas pu traiter votre requête en raison d'une spécification de modèle manquante.",
	e_400_10:	"Requête incorrecte\r\rLe serveur n'a pas pu traiter votre requête en raison d'une grammaire non prise en charge.  \"^1\".",
	e_400_11:	"Requête incorrecte\r\rLe serveur n'a pas pu traiter votre requête en raison d'une requête mal formulée (#^1).",
	e_400_12:	"Requête incorrecte\r\rLe serveur n'a pas pu traiter votre requête car votre session a expiré.\r\rVeuillez sélectionner à nouveau la base de données pour débuter une nouvelle session.",
	e_403_0:	"Interdit\r\rVous n'avez pas l'autorisation d'accéder à ce serveur.",
	e_403_1:	"Limitation d'utilisateurs dépassée\r\rLe nombre maximum de connexions d'utilisateurs autorisés est atteint. Réessayez plus tard.",
	e_404_0:	"Introuvable\r\rL’URL demandée\“^1\” n’a pas été trouvée sur ce serveur.",
	e_417_0:	"Echec des prévisions\r\rLe serveur n'a pas pu effectuer la mise à jour demandée (#^1).",
	e_500_0:	"Erreur de serveur interne\r\rUne erreur de serveur interne s'est produite.",
	e_500_1:	"Erreur de serveur interne\r\rUne erreur de FileMaker Server s'est produite (#^1).",
	e_500_2:	"Erreur de serveur interne\r\rAucun serveur FileMaker Server n'a été trouvé (#^1).",
	e_501_0:	"Non pris en charge\r\rLe serveur ne prend pas en charge la fonctionnalité requise pour satisfaire cette requête.",
	e_505_0:	"Version HTTP non prise en charge\r\rLe serveur ne prend pas en charge la version du protocole HTTP utilisée dans le message de requête.",
	e_default:	"Numéro d'erreur inconnu ^1."
};