/*===================================================================================

  copyright: (C) Copyright 2003-2004 Filemaker, Inc. All Rights Reserved
  
  =================================================================================*/

window.errs = {
	http:		true,
	e_200_0:	"OK\r\rGeen fout.",
	e_204_0:	"Geen records gevonden.\r\rEr zijn geen records die met de zoekcriteria overeenkomen.",
	e_400_0:	"Ongeldig verzoek.\r\rDe server kan uw verzoek niet verwerken vanwege een syntaxisfout.",
	e_400_1:	"Ongeldig verzoek.\r\rDe server kan uw verzoek niet verwerken vanwege een slecht gevormde URL.",
	e_400_2:	"Ongeldig verzoek.\r\rDe server kan uw verzoek niet verwerken vanwege een ontbrekende parameter: \"^1\".",
	e_400_3:	"Ongeldig verzoek.\r\rDe server kan uw verzoek niet verwerken vanwege een leeg veld: \"^1\".",
	e_400_4:	"Ongeldig verzoek.\r\rDe server kan uw verzoek niet verwerken vanwege een ongeldige parameter: \"^1\".",
	e_400_5:	"Ongeldig verzoek.\r\rDe server kan uw verzoek niet verwerken vanwege een minder belangrijk gemaakte parameter: \"^1\".",
	e_400_6:	"Ongeldig verzoek.\r\rDe server kan uw verzoek niet verwerken vanwege een ontbrekende opdracht: \"^1\".",
	e_400_7:	"Ongeldig verzoek.\r\rDe server kan uw verzoek niet verwerken vanwege strijdige opdrachten.",
	e_400_8:	"Ongeldig verzoek.\r\rDe server kan uw verzoek niet verwerken vanwege een ontbrekende databasespecificatie.",
	e_400_9:	"Ongeldig verzoek.\r\rDe server kan uw verzoek niet verwerken vanwege een ontbrekende lay-outspecificatie.",
	e_400_10:	"Ongeldig verzoek.\r\rDe server kan uw verzoek niet verwerken vanwege een niet-ondersteunde grammatica: \"^1\".",
	e_400_11:	"Ongeldig verzoek.\r\rDe server kan uw verzoek niet verwerken vanwege een verkeerd opgestelde opvraag (#^1).",
	e_400_12:	"Ongeldig verzoek.\r\rDe server kan uw verzoek niet verwerken omdat er een time-out voor uw sessie is opgetreden.\r\rSelecteer de database opnieuw om een nieuwe sessie te beginnen.",
	e_403_0:	"Verboden.\r\rU hebt geen toestemming om toegang te krijgen tot deze server.",
	e_403_1:	"Gebruikerslimiet overschreden.\r\rHet maximumaantal geregistreerde gebruikers is al verbonden. Probeer het later opnieuw.",
	e_404_0:	"Niet gevonden.\r\rDe gevraagde URL \"^1\" is niet op deze server gevonden.",
	e_417_0:	"Verwacht resultaat niet verkregen.\r\rDe server kan de gevraagde update (#^1) niet uitvoeren.",
	e_500_0:	"Interne serverfout.\r\rEr is een interne serverfout opgetreden.",
	e_500_1:	"Interne serverfout.\r\rEr is een FileMaker Server-fout opgetreden (#^1).",
	e_500_2:	"Interne serverfout.\r\rFileMaker Server is niet gevonden (#^1).",
	e_501_0:	"Niet geïmplementeerd.\r\rDe server ondersteunt de vereiste functionaliteit niet om aan dit verzoek te voldoen.",
	e_505_0:	"HTTP-versie niet ondersteund.\r\rDe server ondersteunt de versie van het HTTP-protocol dat in het verzoekbericht is gebruikt, niet.",
	e_default:	"Onbekende fout. Nummer ^1."
};
