ZEKTOR   CHIP PLACEMENT


ROM BOARD ASSY        800-3156 ( 800-0151 )
XY TIMING             800-0161
XY CONTROL            800-0163
CPU                   800-3157
SECURITY CHIP         315-0082
SOUND (MEATBALL)      800-3174
SPEECH                800-0183



Zektor (Revision B)
File Name	Location	Size	Checksum
---------	--------	----	--------
1586.bin	Rom U1		2716	01AD
1587.bin	Rom U2		2716	C729
1588.bin	Rom U3		2716	687F
1589.bin	Rom U4		2716	1414
1590.bin	Rom U5		2716	1F49
1591.bin	Rom U6		2716	E702
1592.bin	Rom U7		2716	D186
1593.bin	Rom U8		2716	CC23
1594.bin	Rom U9		2716	0618
1595.bin	Rom U10		2716	924B
1596.bin	Rom U11		2716	B9EC
1597.bin	Rom U12		2716	8459
1598.bin	Rom U13		2716	B230
1599.bin	Rom U14		2716	9CAB
1600.bin	Rom U15		2716	8D46
1601.bin	Rom U16		2716	D870
1602.bin	Rom U17		2716	AF4C
1603.bin	Rom U18		2716	5D9B
1604.bin	Rom U19		2716	0504
1605.bin	Rom U20		2716	5E4E
1606.bin	Rom U21		2716	07E1
S-C.u39.bin	XY Timing U39	2708	8B20
1611.bin	CPU U25		2716	7420
1607.bin	Speech U7	2716	7444
1608.bin	Speech U6	2732	712D
1609.bin	Speech U5	2732	2E52
1610.bin	Speech U4	2732	9BEE