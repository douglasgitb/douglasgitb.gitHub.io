TAC/SCAN   CHIP PLACEMENT


ROM BOARD ASSY        800-3156 ( 800-0151 )
XY TIMING             800-0161
XY CONTROL            800-0163
CPU                   800-3157
SECURITY CHIP         315-0070
SOUND (MEATBALL)      800-3174



Tac/Scan (Set 1)
File Name	Location	Size	Checksum
---------	--------	----	--------
1670.bin	Rom U1		2716	070C
1671.bin	Rom U2		2716	2CD5
1672.bin	Rom U3		2716	6E39
1673.bin	Rom U4		2716	426C
1674.bin	Rom U5		2716	4A61
1675.bin	Rom U6		2716	25CE
1676.bin	Rom U7		2716	EC7F
1677.bin	Rom U8		2716	7550
1678.bin	Rom U9		2716	F644
1679.bin	Rom U10		2716	B52A
1680.bin	Rom U11		2716	AED3
1681.bin	Rom U12		2716	4CC2
1682.bin	Rom U13		2716	BA05
1683.bin	Rom U14		2716	10FC
1684.bin	Rom U15		2716	101B
1685.bin	Rom U16		2716	E3A1
1686.bin	Rom U17		2716	EEC4
1687.bin	Rom U18		2716	122E
1688.bin	Rom U19		2716	A8AC
1709.bin	Rom U20		2716	2752
1710.bin	Rom U21		2716	0388
S-C.u39.bin	XY Timing U39	2708	8B20
1711.bin	CPU U25		2716	751C


