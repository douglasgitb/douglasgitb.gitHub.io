ELIMINATOR   CHIP PLACEMENT


ROM BOARD ASSY        800-3156 ( 800-0151 )
XY TIMING             800-0161
XY CONTROL            800-0163
CPU                   800-3157
SECURITY CHIP         315-0070
SOUND (MEATBALL)      800-3174



Eliminator (4 Player)
File Name	Location	Size	Checksum
---------	--------	----	--------
1347.bin	Rom U1		2716	06EB
1348.bin	Rom U2		2716	A776
1349.bin	Rom U3		2716	DE2B
1350.bin	Rom U4		2716	CE97
1351.bin	Rom U5		2716	7ACD
1352.bin	Rom U6		2716	E4F6
1353.bin	Rom U7		2716	817A
1354.bin	Rom U8		2716	193B
1355.bin	Rom U9		2716	CA5D
1356.bin	Rom U10		2716	4118
1357.bin	Rom U11		2716	9238
1358.bin	Rom U12		2716	BA50
1359.bin	Rom U13		2716	250C
1360.bin	Rom U13		2716	DD69
S-C.u39.bin	XY Timing U39	2708	8B20
1390.u25.bin	CPU U25		2716	5E0B



   
