ELIMINATOR   CHIP PLACEMENT


ROM BOARD ASSY        800-3156 ( 800-0151 )
XY TIMING             800-0161
XY CONTROL            800-0163
CPU                   800-3157
SECURITY CHIP         315-0070
SOUND (MEATBALL)      800-3174



Eliminator (2 Player - Set 1)
File Name	Location	Size	Checksum
---------	--------	----	--------
1333.bin	Rom U1		2716	3035
1334.bin	Rom U2		2716	EA2A
1335.bin	Rom U3		2716	D4AB
1336.bin	Rom U4		2716	9F00
1337.bin	Rom U5		2716	852E
1338.bin	Rom U6		2716	A77F
1339.bin	Rom U7		2716	922E
1340.bin	Rom U8		2716	DD78
1341.bin	Rom U9		2716	A6C5
1342.bin	Rom U10		2716	6232
1343.bin	Rom U11		2716	9A98
1344.bin	Rom U12		2716	6D1F
1345.bin	Rom U13		2716	FAEA
S-C.u39.bin	XY Timing U39	2708	8B20
969.u25.bin	CPU U25		2716	5E0B