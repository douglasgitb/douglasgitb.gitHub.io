ELIMINATOR   CHIP PLACEMENT


ROM BOARD ASSY        800-3156 ( 800-0151 )
XY TIMING             800-0161
XY CONTROL            800-0163
CPU                   800-3157
SECURITY CHIP         315-0076
SOUND (MEATBALL)      800-3174



Eliminator (4 Player - Prototype)
File Name	Location	Size	Checksum
---------	--------	----	--------
sw1.bin		Rom U1		2716	117A
sw2.bin		Rom U2		2716	B297
sw3.bin		Rom U3		2716	DB9A
sw4.bin		Rom U4		2716	CD7D
sw5.bin		Rom U5		2716	734A
sw6.bin		Rom U6		2716	E132
sw7.bin		Rom U7		2716	7664
sw8.bin		Rom U8		2716	09CB
sw9.bin		Rom U9		2716	C8F5
swa.bin		Rom U10		2716	549C
swb.bin		Rom U11		2716	8816
swc.bin		Rom U12		2716	BFC7
swd.bin		Rom U13		2716	29BD
swe.bin		Rom U14		2716	1E23
S-C.u39.bin	XY Timing U39	2708	8B20
1390.u25.bin	CPU U25		2716	5E0B