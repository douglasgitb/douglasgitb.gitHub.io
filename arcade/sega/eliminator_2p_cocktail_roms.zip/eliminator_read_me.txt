ELIMINATOR   CHIP PLACEMENT


ROM BOARD ASSY        800-3156 ( 800-0151 )
XY TIMING             800-0161
XY CONTROL            800-0163
CPU                   800-3157
SECURITY CHIP         315-0070
SOUND (MEATBALL)      800-3174



Eliminator (2 Player - cocktail)
File Name	Location	Size	Checksum
---------	--------	----	--------
1200.bin	Rom U1		2716	2F61
1201.bin	Rom U2		2716	F1CC
1202.bin	Rom U3		2716	CD06
1203.bin	Rom U4		2716	AD07
1204.bin	Rom U5		2716	C2DB
1205.bin	Rom U6		2716	9299
1206.bin	Rom U7		2716	A2E4
1207.bin	Rom U8		2716	D426
1208.bin	Rom U9		2716	A4D8
1209.bin	Rom U10		2716	57D8
1210.bin	Rom U11		2716	AC14
1211.bin	Rom U12		2716	5CDE
1212.bin	Rom U13		2716	DDE6
S-C.u39.bin	XY Timing U39	2708	8B20
969t.u25.bin	CPU U25		2716	23B4


This is the list of Checksums for the 2 player
Eliminator Cocktail from the House of Pinball
Collection... (Dangerous Dann)