Space Fury Set B
Recorded by Mark Jenison

960B.bin	U1 EPROM board
961B.bin	U2 EPROM board
962B.bin	U3 EPROM board
963B.bin	U4 EPROM board
964B.bin	U5 EPROM board
965B.bin	U6 EPROM board
966B.bin	U7 EPROM board
967B.bin	U8 EPROM board
968B.bin	U9 EPROM board
969B_cpu.bin	U25 CPU board
808B_snd.bin	U7 SPEECH board
970B_snd.bin	U6 SPEECH board
971B_snd.bin	U5 SPEECH board
972B_snd.bin	U4 SPEECH board

