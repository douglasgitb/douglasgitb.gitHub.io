SPACE FURY  CHIP PLACEMENT


ROM BOARD ASSY        800-3156 ( 800-0151 )
XY TIMING             800-0161
XY CONTROL            800-0163
CPU                   800-3157
SECURITY CHIP         315-0064
SOUND (BATTLESTAR)    800-3174
SPEECH                800-0183



Space Fury (Revision C)
File Name	Location	Size	Checksum
---------	--------	----	--------
960c.u1		Rom U1		2716	19D1
961c.u2		Rom U2		2716	E105
962c.u3		Rom U3		2716	48C2
963c.u4		Rom U4		2716	557B
964c.u5		Rom U5		2716	42DE
965c.u6		Rom U6		2716	D119
966c.u7		Rom U7		2716	DE32
967c.u8		Rom U8		2716	3E6C
968c.u9		Rom U9		2716	C80E
S-C.U39.bin	XY Timing U39	2708	8B20
969c.u25	CPU U25		2716	2DBA
808c.u7		Speech U7	2716	7444
970c.u6		Speech U6	2732	75B0
971c.u5		Speech U5	2732	8D0D
972c.u4		Speech U4	2732	0175