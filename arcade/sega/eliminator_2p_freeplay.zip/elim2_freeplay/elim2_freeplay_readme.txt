Eliminator Upright Free Play
by Mark Jenison

Burn the elim2_cpu_freeplay.rom EPROM data to a 2716 EPROM and install it on the cpu board.
Also, burn the elim2_freeplay_u14.rom and install it in the unoccupied U14 socket on the EPROM Board.
Pressing the 1player or 2player button will start the game with that number of players.  
This version works with both sets of upright Eliminator EPROM set.

NOTE: Sometimes if you press the player 1 or player 2 buttons too fast, the game will not start
immediately and instead ask for you to select the number of players.  Simply press the player button
that matches the number of credit shown.



