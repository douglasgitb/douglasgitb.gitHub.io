SPACE FURY  CHIP PLACEMENT


ROM BOARD ASSY        800-3156 ( 800-0151 )
XY TIMING             800-0161
XY CONTROL            800-0163
CPU                   800-3157
SECURITY CHIP         315-0064
SOUND (BATTLESTAR)    800-3174
SPEECH                800-0183



Space Fury (Revision A)
File Name	Location	Size	Checksum
---------	--------	----	--------
960a.u1		Rom U1		2716	0A92
961a.u2		Rom U2		2716	C20D
962a.u3		Rom U3		2716	518A
963a.u4		Rom U4		2716	5F58
964a.u5		Rom U5		2716	49F8
965a.u6		Rom U6		2716	C188
966a.u7		Rom U7		2716	1F92
967a.u8		Rom U8		2716	2E94
968a.u9		Rom U9		2716	D105
S-C.U39.bin	XY Timing U39	2708	8B20
969a.u25	CPU U25		2716	23B4
808a.u7		Speech U7	2716	70C9
970a.u6		Speech U6	2732	6CF6
971a.u5		Speech U5	2732	7C84
972a.u4		Speech U4	2732	4E8B