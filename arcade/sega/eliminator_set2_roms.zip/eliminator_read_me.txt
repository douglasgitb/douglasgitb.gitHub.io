ELIMINATOR   CHIP PLACEMENT


ROM BOARD ASSY        800-3156 ( 800-0151 )
XY TIMING             800-0161
XY CONTROL            800-0163
CPU                   800-3157
SECURITY CHIP         315-0070
SOUND (MEATBALL)      800-3174



Eliminator (2 Player - Set 2)
File Name	Location	Size	Checksum
---------	--------	----	--------
1158.bin	Rom U1		2716	32D7
1159.bin	Rom U2		2716	F12E
1160a.bin	Rom U3		2716	EAFB
1161a.bin	Rom U4		2716	93AD
1162a.bin	Rom U5		2716	BC83
1163a.bin	Rom U6		2716	88BF
1164a.bin	Rom U7		2716	999E
1165a.bin	Rom U8		2716	D2E6
1166a.bin	Rom U9		2716	8863
1167a.bin	Rom U10		2716	5669
1168a.bin	Rom U11		2716	AA0E
1169a.bin	Rom U12		2716	725F
1170a.bin	Rom U13		2716	DFC8
S-C.u39.bin	XY Timing U39	2708	8B20
969.u25.bin	CPU U25		2716	5E0B